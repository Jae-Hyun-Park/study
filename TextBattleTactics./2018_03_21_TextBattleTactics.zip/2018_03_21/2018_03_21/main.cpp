#include "GameWindow.h"
int main() {
	GameWindow* game = new GameWindow();
	delete game;
	return 0;
}