#pragma once
#include "Character.h"
class Lancer :
	public Character
{
public:
	Lancer(const char* jobname);
	virtual ~Lancer();
};

