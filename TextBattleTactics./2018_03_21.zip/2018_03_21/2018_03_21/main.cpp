#include "GameWindow.h"
int main() {
	GameWindow* game = new GameWindow();
	return 0;
}