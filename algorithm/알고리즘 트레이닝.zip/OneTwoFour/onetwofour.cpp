#include <iostream>

using namespace std;

int main() {
	int num = 0;
	string result = "";
	cout << "input num = ";
	cin >> num;

	while(num != 0) {
		result.append("124", (num - 1) % 3, 1);
		num = (num - 1) / 3;
	}
	reverse(result.begin(), result.end());
	cout << result.c_str() << endl;
	
	return 0;
}