#include <iostream>
#include <string>
#include <vector>

using namespace std;

int Zenerator(int zenerator) {
	int Num = 0;
	string Nums;
	string buffer[5];
	int buffers = 0;

	Nums = to_string(zenerator);
	for (int i = 0; i < Nums.size(); ++i) {
		buffer[i].append(Nums, i, 1);
	}

	for (int i = 0; i < Nums.size(); ++i) {
		buffers += atoi(buffer[i].c_str());
	}
	Num = buffers + zenerator;

	return Num;
}
int main() {
	vector<int> Num;

	vector<int> SelfNumber;
	int count = 0;
	int sumSelfNum = 0;
	int N = 0;
	
	cout << "input N = ";
	cin >> N;

	for (int i = 0; i < N; ++i) {
		SelfNumber.push_back(i);
	}
	for (int i = 0; i < N; ++i) {
		Num.push_back(Zenerator(i));
		if (Num[i] < N)
			SelfNumber[Num[i]] = 0;
	}

	for (int i = 0; i < N; ++i) {
		sumSelfNum += SelfNumber[i];
		if (SelfNumber[i] != 0)
			cout << SelfNumber[i] << ", ";
	}
	cout << endl;
	cout << "Sum = " << sumSelfNum << endl;
	return 0;
}