#include <iostream>
#include <random>

using namespace std;

int getRandomNumber(int min, int max)
{
	//< 1�ܰ�. �õ� ����
	random_device rn;
	mt19937_64 rnd(rn());

	//< 2�ܰ�. ���� ���� ( ���� )
	uniform_int_distribution<int> range(min, max);

	//< 3�ܰ�. �� ����
	return range(rnd);
}

void swap(int* a, int* b) {
	int* temp;
	*temp = *a;
	*a = *b;
	*b = *temp;
}
int main() {
	const int Size = 100000;
	int Num[Size] = { 0, };
	int count = 0;

	for (int i = 0; i < Size; ++i) {
		Num[i] = i;
	}
	for (int j = 0; j < Size; ++j) {
		count = getRandomNumber(0, Size - 1);
		swap(Num[count], Num[j]);
	}
	for (int i = 0; i < Size; ++i) {
		cout << Num[i] << endl;
	}
	return 0;
}