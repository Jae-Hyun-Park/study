#include <iostream>
#include <vector>
#include <random>
#include <ctime>
#include <functional>
#include <bitset>

using namespace std;

string Decrypt(int value, int stringLength)
{
	string returnString = "";
	string numberString = " #";

	int count = 0;
	while (value != 0)
	{
		returnString = numberString[value % 2] + returnString;
		value /= 2;
		count++;
	}

	while (count < stringLength)
	{
		returnString = numberString[0] + returnString;
		count++;
	}
	
	return returnString;
}

int GetRandom(int min, int max)
{
	//< 1�ܰ�. �õ� ����
	random_device rn;
	mt19937_64 rnd(rn());

	//< 2�ܰ�. ���� ���� ( ���� )
	uniform_int_distribution<int> range(min, max);

	//< 3�ܰ�. �� ����
	return range(rnd);
}

void CreateRandomElements(vector<int>& arr, int size)
{
	for (unsigned int i = 0; i < size; ++i)
		arr.push_back(GetRandom(0, pow(2, size)-1));
}

void GetOverlapedArray(vector<int>& newArray, vector<int>& _arr1, vector<int>& _arr2)
{
	for (unsigned int i = 0; i < _arr1.size(); ++i)
	{
		int x = _arr1[i] | _arr2[i];
		newArray.push_back(x);
	}
}

void GetDecryptedMap(vector<string>& decryptedMap, vector<int>& Array)
{
	string row = "";
	for (unsigned int i = 0; i < Array.size(); ++i)
	{
		string row = Decrypt(Array[i], Array.size());
		row.insert(row.begin(), '[');
		row.push_back(']');
		decryptedMap.push_back(row);
	}
}

int main()
{
	int n;
	cout << "������ ũ�⸦ �Է��Ͻÿ� (1~16) : ";
	cin >> n;	cin.ignore();	cin.clear();

	vector<int> arr1, arr2;
	arr1.clear();
	arr2.clear();
	CreateRandomElements(arr1, n);
	CreateRandomElements(arr2, n);

	vector<int> newArray;
	GetOverlapedArray(newArray, arr1, arr2);
	vector<string> decryptedArr1, decryptedArr2, decryptedTotal;

	GetDecryptedMap(decryptedArr1, arr1);
	GetDecryptedMap(decryptedArr2, arr2);
	GetDecryptedMap(decryptedTotal, newArray);

	cout << endl << "-------- ����  1 --------" << endl;
	for (auto str : decryptedArr1)
		cout << str << endl;

	cout << endl << "-------- ����  2 --------" << endl;
	for (auto str : decryptedArr2)
		cout << str << endl;

	cout << endl << "---- �ص��Ϸ��� ���� ----" << endl;
	for (auto str : decryptedTotal)
		cout << str << endl;

	return 0;
}
