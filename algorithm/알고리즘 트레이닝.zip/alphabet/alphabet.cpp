#include <iostream>
#include <string>
#include <vector>

using namespace std;

string alphabets = "abcdefghijklmnopqrstuvwxyz";


void combNum(string res, string input) {
	if (input.size() == 0) {
		cout << res << endl;
		return;
	}

	string buffer = input.substr(0, 1);
	combNum(res + alphabets[atoi(buffer.c_str()) - 1], input.substr(1, input.length() - 1));

	buffer = input.substr(0, 2);

	if (buffer.length() >= 2 && atoi(buffer.c_str()) <= 26) {
		combNum(res + alphabets[atoi(buffer.c_str()) - 1], input.substr(2, input.length() - 2));
	}
}
int main() {
	string input;
	string res = "";

	cout << "input = ";
	cin >> input;

	combNum(res, input);
	
	return 0;
}