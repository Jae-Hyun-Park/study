﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework01
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, t, m, p;

            while (!InputNotation(out n)) ;
            while (!InputAnswerCount(out t)) ;
            while (!InputPlayerCount(out m)) ;
            while (!InputMyOrder(out p, m)) ;

            string answer = "";         // 최종 답으로 출력할 문자열

            string strNumber = "";      // 숫자 하나당 해당 진법으로 변환 되어 나온 문자열
            int number = 0;             // 증가 시키면서 변환할 숫자
            int currentOrder = 0;       // 현재 전체 턴수
            while (true)
            {
                strNumber = number != 0 ? ConvertNotation(number, n) : number.ToString();

                int index = 0;
                while (index < strNumber.Length)
                {
                    if (((currentOrder % m) + 1) == p)
                    {
                        answer += strNumber[index];
                    }
                    index++;
                    currentOrder++;

                    if (answer.Length >= t)
                        break;
                }
                number++;
                if (answer.Length >= t)
                    break;
            }

            Console.WriteLine("내 순서에 말해야 할 답 : " + answer.ToUpper());
        }

        static bool InputNotation(out int _n)
        {
            Console.Write("진법 (2 ~ 16) : ");
            string str = Console.ReadLine();
            if (int.TryParse(str, out _n) == true)
            {
                if (_n >= 2 && _n <= 16)
                    return true;
            }
            Console.WriteLine("잘못 입력하셨습니다.");
            return false;
        }

        static bool InputAnswerCount(out int _t)
        {
            Console.Write("미리 구할 숫자갯수(0 ~ 1000) : ");
            string str = Console.ReadLine();
            if (int.TryParse(str, out _t))
                if (_t >= 0 && _t <= 16)
                    return true;
            Console.WriteLine("잘못 입력하셨습니다.");
            return false;
        }

        static bool InputPlayerCount(out int _m)
        {
            Console.Write("플레이어 수(2 ~ 100) : ");
            string str = Console.ReadLine();
            if (int.TryParse(str, out _m))
                if (_m >= 2 && _m <= 100)
                    return true;
            Console.WriteLine("잘못 입력하셨습니다.");
            return false;
        }

        static bool InputMyOrder(out int _p, int maxPlayers)
        {
            Console.Write("내 순서 (1 ~ " + maxPlayers + ") : ");
            string str = Console.ReadLine();
            if (int.TryParse(str, out _p))
                if (_p >= 1 && _p <= maxPlayers)
                    return true;
            Console.WriteLine("잘못 입력하셨습니다.");
            return false;
        }

        static string ConvertNotation(int value, int i)
        {
            string returnString = "";
            string numberString = "0123456789ABCDEF";

            while (value != 0)
            {
                returnString = numberString[value % i] + returnString;
                value /= i;
            }

            return returnString;
        }
    }
}