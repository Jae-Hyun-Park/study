#pragma once
#include "SDLGameObject.h"
class SDLAniSpriteObj :
	public SDLGameObject
{
private:
	unsigned int horizonCount = 1;
	unsigned int verticalCount = 1;
	float frameRate;
	float elapsedTime;
	int frameCount;

public:
	SDLAniSpriteObj(SDL_Renderer* renderer, string filePath);
	~SDLAniSpriteObj();

	void SetFrameRate(float _frameRate) { frameRate = _frameRate; }
	void SetHorizonCount(unsigned int hCount) { horizonCount = hCount; }
	void SetVerticalCount(unsigned int vCount) { verticalCount = vCount; }
	void Render(SDL_Renderer* renderer, float deltaTime) override;
};

