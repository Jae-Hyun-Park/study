#include "SDLGameObject.h"



SDLGameObject::SDLGameObject(SDL_Renderer* renderer, string filePath)
{// �ؽ��� �ε�
	texture = Utilities::LoadTexture(renderer, filePath);

	// �ؽ��� ���� ���ϱ�
	SDL_QueryTexture(texture, NULL, NULL, &(clipRect.w), &(clipRect.h));

	// ��ġ �� ũ�� �ʱ�ȭ
	clipRect.x = 0; clipRect.y = 0;
	projRect.x = 0; projRect.y = 0;
	textureWidth = projRect.w = clipRect.w;
	textureHeight = projRect.h = clipRect.h;

	shareTexture = NULL;
}


SDLGameObject::~SDLGameObject()
{
	SDL_DestroyTexture(texture);
}

void SDLGameObject::SetTexture(SDL_Texture * _tex)
{
	shareTexture = _tex;
}

void SDLGameObject::SetPosition(int x, int y)
{
	projRect.x = x; projRect.y = y;
}

void SDLGameObject::SetWidth(int width)
{
	projRect.w = width;
}

void SDLGameObject::SetHeight(int height)
{
	projRect.h = height;
}

void SDLGameObject::Render(SDL_Renderer* renderer, float deltaTime)
{
	SDL_RenderCopy(renderer, (shareTexture != NULL ? shareTexture : texture), &clipRect, &projRect);
}
