#include "SDLAniSpriteObj.h"


SDLAniSpriteObj::SDLAniSpriteObj(SDL_Renderer * renderer, string filePath, SDL_Color* keyColor)
	: SDLGameObject(renderer, filePath, keyColor)
{
	elapsedTime = 0.0f;
	frameCount = 0;
}


SDLAniSpriteObj::~SDLAniSpriteObj()
{
}

void SDLAniSpriteObj::Render(SDL_Renderer* renderer, float deltaTime)
{
	elapsedTime += deltaTime;
	if (elapsedTime > frameRate) {
		frameCount++;
		if (frameCount >= horizonCount * verticalCount)
			frameCount = 0;

		elapsedTime = 0.0f;
	}
	unsigned int sizeHorizontal = textureWidth / horizonCount;
	unsigned int sizeVertical = textureHeight / verticalCount;

	unsigned int xPos, yPos;
	xPos = frameCount % horizonCount;
	yPos = frameCount / horizonCount;

	clipRect.x = xPos * sizeHorizontal;
	clipRect.y = yPos * sizeVertical;
	clipRect.w = sizeHorizontal;
	clipRect.h = sizeVertical;

	SDLGameObject::Render(renderer, deltaTime);
}
