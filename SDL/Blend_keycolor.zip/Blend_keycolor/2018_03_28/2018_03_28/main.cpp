//SDL�� ǥ������� ����
#include "include\SDL.h"
#include "include\SDL_image.h"
#include <iostream>
#include <string>
#include "SDLAniSpriteObj.h"
using namespace std;

//ȭ��ũ��
const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

bool Init();
void Close();

// ������ �� â (window)
SDL_Window* gwindow = NULL;

// ������ �� ������
SDL_Renderer* gRenderer = NULL;


enum KeyPressState {
	KEY_PRESS_DEFAULT,
	KEY_PRESS_UP,
	KEY_PRESS_DOWN,
	KEY_PRESS_RIGHT,
	KEY_PRESS_LEFT
};

int main(int argc, char* args[]) {
	int now, last = 0;
	float deltatime = 0.0f;
	if (!Init()) {
		cout << "Failed to initialized!" << endl;
		return 0;
	}

	bool quit = false; // ���α׷� ������½� true�� �ٲ�� ����
	SDL_Event sdlEvent;

	int frameTime = 1000;
	int elapsedTime = 0;
	int xIndex = 0;
	int yIndex = 0;

	SDLGameObject* gameObj = new SDLAniSpriteObj(gRenderer, "./media/Texture.png");
	SDLGameObject* blendObj = new SDLAniSpriteObj(gRenderer, "./media/blend.png");
	blendObj->SetBlendMode(SDL_BLENDMODE_BLEND);
	blendObj->SetAlpha(0x88);

	/*SDLAniSpriteObj* aniSpriteObj = new SDLAniSpriteObj(gRenderer, "./media/bCircle.png");
	aniSpriteObj->SetFrameRate(0.5f);
	aniSpriteObj->SetHorizonCount(3);
	aniSpriteObj->SetVerticalCount(2);
	aniSpriteObj->SetPosition(100, 40);*/
	gameObj->SetWidth(640);
	gameObj->SetHeight(480);
	while (!quit) {
		now = SDL_GetTicks();
		if (now > last) {
			elapsedTime += now - last;
			deltatime = ((float)(now - last)) / 1000.0f;
			last = now;
		}
		while (SDL_PollEvent(&sdlEvent) != 0) {
			if (sdlEvent.type == SDL_QUIT)
				quit = true;
			else if (sdlEvent.type == SDL_KEYDOWN) {
				
			}
			else if (sdlEvent.type == SDL_KEYUP) {}
		}
		if (gRenderer != NULL) {
			// Clear screen
			SDL_RenderClear(gRenderer);

			gameObj->Render(gRenderer, deltatime);
			blendObj->Render(gRenderer, deltatime);
			/*aniSpriteObj->Render(gRenderer, deltatime);*/

			// UpdateScreen
			SDL_RenderPresent(gRenderer);
		}
	}
	Close();
	return 0;
}

bool Init() {
	bool success = true;
	//SDL �ʱ�ȭ
	if (SDL_Init(SDL_INIT_EVERYTHING) < 0) {           // SDL �ʱ�ȭ ���н�
		printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
		success = false;
	}
	else {                                              // �ʱ�ȭ����
														//������ ����
		gwindow = SDL_CreateWindow(
			"SDL Tutorial",      // Ÿ��Ʋ
			SDL_WINDOWPOS_UNDEFINED, // x��ǥ
			SDL_WINDOWPOS_UNDEFINED, // y��ǥ
			SCREEN_WIDTH,            // ȭ��ʺ�
			SCREEN_HEIGHT,            // ȭ�����
			SDL_WINDOW_SHOWN         // â���̱�
		);
		if (gwindow == NULL) {
			printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
			success = false;
		}
		else {
			//Create Rederer for Window
			gRenderer = SDL_CreateRenderer(gwindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

			if (gRenderer == NULL) {
				printf("Renderer could not be created! SDL_Error: %s\n", SDL_GetError());
				success = false;
			}
			else {
				SDL_SetRenderDrawColor(gRenderer, 0xFF, 0xFF, 0xFF, 0xFF);

				int imgFlags = IMG_INIT_PNG;
				if (!(IMG_Init(imgFlags) & imgFlags)) {
					printf("SDL_Image could not initialize! SDL_Error: %s\n", SDL_GetError());
					success = false;
				}
			}
		}
	}
	return success;
}

void Close() {
	// �ؽ��� �ı�
	// ������ �ı�
	SDL_DestroyRenderer(gRenderer);
	gRenderer = NULL;
	//â �ı�
	SDL_DestroyWindow(gwindow);
	gwindow = NULL;
	//SDL �����ý��� ������
	IMG_Quit();
	SDL_Quit();
	return;
}
