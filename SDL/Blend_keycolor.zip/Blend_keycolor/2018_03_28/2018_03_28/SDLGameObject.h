#pragma once
#include "Utilities.h"
class SDLGameObject
{
protected:
	SDL_Rect		clipRect;		// Render�ÿ� Texture�� ���� Ŭ���� �� ����
	SDL_Rect		projRect;		// ���� ��ġ�� ũ�⸦ ��Ÿ���� ����
	SDL_Texture*	texture;
	SDL_Texture*	shareTexture;
	unsigned int	textureWidth;
	unsigned int	textureHeight;

public:
	SDLGameObject(SDL_Renderer* renderer, string filePath, SDL_Color* keycolor = NULL);
	virtual ~SDLGameObject();

	void SetTexture(SDL_Texture* _tex);
	void SetPosition(int x, int y);
	void SetWidth(int width);
	void SetHeight(int height);
	SDL_Texture* GetTexture() {
		return shareTexture != NULL ? shareTexture : texture;
	}
	void SetBlendMode(SDL_BlendMode blendMode);
	void SetAlpha(Uint8 alpha);
	virtual void Render(SDL_Renderer* renderer, float deltaTime);
};

