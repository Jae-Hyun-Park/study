#include "SDLGameObject.h"
#include "Utilities.h"

SDLGameObject::SDLGameObject(SDL_Renderer* renderer, string filePath, SDL_Color* keyColor)
{
	// �ؽ��� �ε�
	texture = Utilities::LoadTexture(renderer, filePath, keyColor);

	// �ؽ��� ���� ���ϱ�
	SDL_QueryTexture(texture, NULL, NULL,
		&(clipRect.w), &(clipRect.h));

	// ��ġ �� ũ�� �ʱ�ȭ
	clipRect.x = 0; clipRect.y = 0;
	projRect.x = 0; projRect.y = 0;
	textureWidth = projRect.w = clipRect.w;
	textureHeight = projRect.h = clipRect.h;

	shareTexture = NULL;
	flipMode = SDL_FLIP_NONE;
	centerPoint = NULL;
	angle = 0.0f;
}

SDLGameObject::~SDLGameObject()
{
	SDL_DestroyTexture(texture);
}

void SDLGameObject::SetTexutre(SDL_Texture * _tex)
{
	shareTexture = _tex;
}

void SDLGameObject::SetPosition(int x, int y)
{
	projRect.x = x; projRect.y = y;
}

void SDLGameObject::SetWidth(int width)
{
	projRect.w = width;
}

void SDLGameObject::SetHeight(int height)
{
	projRect.h = height;
}

void SDLGameObject::SetRotate(double _angle)
{
	angle = _angle;
}

void SDLGameObject::SetFlipMode(SDL_RendererFlip flip)
{
	flipMode = flip;
}

void SDLGameObject::SetCenterPoint(SDL_Point* center)
{
	centerPoint = center;
}

void SDLGameObject::SetBlendMode(SDL_BlendMode blendMode)
{
	SDL_SetTextureBlendMode(GetTexture(), blendMode);
}

void SDLGameObject::SetAlpha(Uint8 alpha)
{
	SDL_SetTextureAlphaMod(GetTexture(), 0x88);
}

void SDLGameObject::Render(SDL_Renderer* renderer, float deltaTime)
{
	SDL_RenderCopyEx(renderer, GetTexture(), &clipRect, &projRect, angle, centerPoint, flipMode);
}
