#include "SDLFontObject.h"



SDLFontObject::SDLFontObject()
{
}


SDLFontObject::~SDLFontObject()
{
}
