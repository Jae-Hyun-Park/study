//// Render Texture to Screen
//SDL_Rect src, dst;
//int width, height;
//SDL_QueryTexture(gTexture, NULL, NULL, &width, &height);
//SDL_RenderCopy(gRenderer, gTexture, &src, &dst);