//SDL�� ǥ������� ����
#include <iostream>
#include <string>
#include <vector>
#include "include\SDL.h"
#include "include\SDL_image.h"
#include "include\SDL_ttf.h"
#include "SDLAniSpriteObj.h"
#include "SDLTextObject.h"

using namespace std;

//ȭ��ũ��
const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

bool Init();
void Close();

//������ �� â(window)
SDL_Window* gWindow = NULL;

//������ �� ������
SDL_Renderer* gRenderer = NULL;

//����� ��Ʈ
TTF_Font* gFont = NULL;

// RenderObjectVector
vector<SDLGameObject*> gameObjects;

int main(int argc, char* args[])
{
	int now, last = 0;			// now : ���� �����ӿ����� �ð��� ����� ����
								// last : ���� �����ӿ����� �ð��� ����� ����
	float deltaTime = 0.0f;		// ���� �����ӿ��� ���� ���� �����ӱ��� �ɸ� �ð�

	if (!Init())
	{
		cout << "Failed to initialized!!" << endl;
		return 0;
	}

	bool quit = false;			// ���α׷� ������°� �Ǹ� true�� �ٲ� ����
	SDL_Event sdlEvent;

	int frameTime = 1000;
	int elapsedTime = 0;

	int xIndex = 0;
	int yIndex = 0;

	SDLGameObject* gameObj = new SDLAniSpriteObj(gRenderer, "./Media/Arrow.png");
	gameObj->SetPosition(200, 200);

	SDLGameObject* roratedObj = new SDLAniSpriteObj(gRenderer, "./Media/Arrow.png");
	roratedObj->SetPosition(200, 200);
	SDL_Point center;
	center.x = -25;
	center.y = -25;
	roratedObj->SetCenterPoint(&center);
	roratedObj->SetRotate(45.0);
	roratedObj->SetBlendMode(SDL_BLENDMODE_BLEND);
	roratedObj->SetAlpha(0x88);

	SDLGameObject* roratedObj2 = new SDLAniSpriteObj(gRenderer, "./Media/Arrow.png");
	roratedObj2->SetPosition(200, 200);
	roratedObj2->SetRotate(45.0);
	roratedObj2->SetBlendMode(SDL_BLENDMODE_BLEND);
	roratedObj2->SetAlpha(0x88);

	SDLTextObject* fontObject = new SDLTextObject();
	fontObject->SetPosition(300, 200);
	fontObject->SetText(gRenderer, gFont, "THIS IS DIABLO FONT!!");

	//gameObj->SetFlipMode(SDL_FLIP_VERTICAL);

	//SDLAniSpriteObj* aniSpriteObj = new SDLAniSpriteObj(gRenderer, "./Media/bCircle.png");
	//aniSpriteObj->SetFrameRate(0.1f);
	//aniSpriteObj->SetHorizonCount(3);
	//aniSpriteObj->SetVerticalCount(2);
	//aniSpriteObj->SetPosition(100, 40);
	//aniSpriteObj->SetWidth(100);
	//aniSpriteObj->SetHeight(200);

	gameObjects.push_back(gameObj);
	gameObjects.push_back(roratedObj);
	gameObjects.push_back(roratedObj2);
	gameObjects.push_back(fontObject);
	//gameObjects.push_back(aniSpriteObj);

	while (!quit)
	{
		// Tick�� Time ���
		now = SDL_GetTicks();
		if (now > last)
		{
			elapsedTime += now - last;
			deltaTime = ((float)(now - last)) / 1000.0f;
			last = now;
		}

		while (SDL_PollEvent(&sdlEvent) != 0)
		{
			if (sdlEvent.type == SDL_QUIT)
			{
				quit = true;
			}
			else if (sdlEvent.type == SDL_KEYDOWN)
			{
			}
			else if (sdlEvent.type == SDL_KEYUP)
			{
			}
		}

		if (gRenderer != NULL)
		{
			// Clear screen
			SDL_RenderClear(gRenderer);

			// Object Render
			//gameObj->Render(gRenderer, deltaTime);
			//blendObj->Render(gRenderer, deltaTime);
			//aniSpriteObj->Render(gRenderer, deltaTime);
			
			for (auto object : gameObjects)
			{
				object->Render(gRenderer, deltaTime);
			}

			// UpdateScreen
			SDL_RenderPresent(gRenderer);
		}
	}

	Close();

	return 0;
}

bool Init()
{
	bool success = true;
	//SDL �ʱ�ȭ
	if (SDL_Init(SDL_INIT_EVERYTHING) < 0)		// SDL �ʱ�ȭ ���н�
	{
		printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
		success = false;
	}
	else										// �ʱ�ȭ ������
	{
		//������ ����
		gWindow = SDL_CreateWindow(
			"SDL Tutorial",    //Ÿ��Ʋ
			SDL_WINDOWPOS_UNDEFINED,  //x��ǥ
			SDL_WINDOWPOS_UNDEFINED,  //y��ǥ
			SCREEN_WIDTH,     //ȭ��ʺ�
			SCREEN_HEIGHT,     //ȭ�����
			SDL_WINDOW_SHOWN   //â ���̱�
		);

		if (gWindow == NULL)
		{
			printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
			success = false;
		}
		else
		{
			//Create Renderer for Window
			gRenderer = SDL_CreateRenderer(gWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

			if (gRenderer == NULL)
			{
				printf("Renderer Could not be created! SDL_Error: %s\n", SDL_GetError());
				success = false;
			}
			else
			{

				if (TTF_Init() == -1)
				{
					cout << "SDL_ttf could not initialize! SDL_ttf Error : " << TTF_GetError() << endl;
					success = false;
				}
				else
				{
					gFont = TTF_OpenFont("./Media/Font/DiabloLight.ttf", 48);
					if (gFont == NULL)
					{
						cout << "Failed to load Diablo font! SDL_ttf Error : " << TTF_GetError() << endl;
						success = false;
					}
				}

				// ��׶��� �� ä���
				SDL_SetRenderDrawColor(gRenderer, 0xFF, 0xFF, 0xFF, 0xFF);

				int imgFlags = IMG_INIT_PNG;
				if ( !( IMG_Init(imgFlags) & imgFlags ) )
				{
					cout << "SDL_Image Could not initialize! SDL_Error : " << SDL_GetError() << endl;
					success = false;
				}
			}
		}
	}

	return success;
}

void Close()
{
	for (auto object : gameObjects)
	{
		delete object;
	}
	gameObjects.clear();

	// ��Ʈ �ı�
	TTF_CloseFont(gFont);
	gFont = NULL;

	// ������ �ı�
	SDL_DestroyRenderer(gRenderer);
	gRenderer = NULL;

	//â �ı�
	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	//SDL �����ý��� ������
	TTF_Quit();
	IMG_Quit();
	SDL_Quit();
}
