#pragma once
#include "SDLGameObject.h"
class SDLFontObject :
	public SDLGameObject
{
public:
	SDLFontObject();
	~SDLFontObject();
};

