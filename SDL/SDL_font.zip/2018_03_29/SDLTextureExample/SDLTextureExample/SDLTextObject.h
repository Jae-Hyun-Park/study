#pragma once
#include "SDLGameObject.h"
#include "include\SDL_ttf.h"
class SDLTextObject : 
	public SDLGameObject
{
private:
	string text;

public:
	SDLTextObject();
	~SDLTextObject();

	void SetText(SDL_Renderer* renderer, TTF_Font* font, string _text, SDL_Color* color = NULL);
	string GetText() { return text; }
};

