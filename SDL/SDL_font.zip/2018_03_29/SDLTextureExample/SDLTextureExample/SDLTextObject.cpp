#include "SDLTextObject.h"
#include "Utilities.h"

SDLTextObject::SDLTextObject()
{
}


SDLTextObject::~SDLTextObject()
{
}

void SDLTextObject::SetText(SDL_Renderer* renderer, TTF_Font* font, string _text, SDL_Color* color)
{
	text = _text;
	texture = Utilities::LoadTextureFromFont(renderer, font, text, color);

	// �ؽ��� ���� ���ϱ�
	SDL_QueryTexture(texture, NULL, NULL,
		&(clipRect.w), &(clipRect.h));

	// ��ġ �� ũ�� �ʱ�ȭ
	clipRect.x = 0; clipRect.y = 0;
	projRect.x = 0; projRect.y = 0;
	textureWidth = projRect.w = clipRect.w;
	textureHeight = projRect.h = clipRect.h;

	shareTexture = NULL;
	flipMode = SDL_FLIP_NONE;
	centerPoint = NULL;
	angle = 0.0f;
}
