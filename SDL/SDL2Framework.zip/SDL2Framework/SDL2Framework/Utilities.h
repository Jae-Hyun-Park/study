#pragma once
#include <iostream>
#include <string>
#include "include\SDL.h"
#include "include\SDL_image.h"
#include "include\SDL_ttf.h"

using namespace std;

class Utilities
{
public:
public:
	Utilities();
	~Utilities();
};

