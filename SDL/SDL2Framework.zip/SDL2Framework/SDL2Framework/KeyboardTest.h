#pragma once
#include "Component.h"

class Collider;

class KeyboardTest :
	public Component
{
public:
	KeyboardTest();
	~KeyboardTest();

	void Update(float deltaTime);

	void OnCollisionEnter(Collider* other);
	void OnCollisionExit(Collider* other);
};

