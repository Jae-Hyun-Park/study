#include "SDLFramework.h"
#include "GameManager.h"
#include "Texture.h"
#include "Transform.h"
#include "Text.h"
#include "MouseTest.h"
#include "KeyboardTest.h"
#include "RectangleCollider.h"
#include "CircleCollider.h"

GameManager::GameManager()
{
}

GameManager::~GameManager()
{
}

void GameManager::Init()
{
	scene = new Scene();
	// ��Ʈ �ε�
	SDLFramework::Instance()->RegisterFont("./Media/Font/DiabloLight.ttf", 48);

	// �̰��� ���ӿ� �ʿ��� ������Ʈ �Ǵ� Scene ���� �ʱ� ��ġ �� ����մϴ�.
	ChangeScene(SceneName::MainMenu);
}

void GameManager::Release()
{
}

void GameManager::ChangeScene(SceneName sceneName)
{
	if (currentSceneName == sceneName)
		return;

	// scene�� ����ִ� ��� ������Ʈ���� �ı�
	scene->DestroyAll();

	// scene ��ȯ
	currentSceneName = sceneName;
	switch (currentSceneName)
	{
	case MainMenu:
		SetMainMenuScene();
		break;
	case Game:
		SetGameScene();
		break;
	}
}

void GameManager::SetMainMenuScene()
{
	SDLGameObject* titleObject = new SDLGameObject("Title");
	SDL_Texture* tex = SDLFramework::LoadTexture("./Media/Arrow.png");

	scene->Register_SDLTexture("TitleTexture", tex);

	Texture* titleTexture = titleObject->AddComponent<Texture>();
	titleTexture->SetTexutre(scene->Get_SDLTexture("TitleTexture"));
	titleObject->transform->SetPosition(100, 100);
	titleObject->transform->SetWidth(500);
	titleObject->transform->SetHeight(100);
	titleObject->AddComponent<KeyboardTest>();
	scene->RegisterGameObject(titleObject);
}

void GameManager::SetGameScene()
{
	SDLGameObject* titleObject = new SDLGameObject("Player");
	SDL_Texture* tex = SDLFramework::LoadTexture("./Media/bCircle.png");

	scene->Register_SDLTexture("PlayerTexture", tex);

	Texture* titleTexture = titleObject->AddComponent<Texture>();
	titleTexture->SetTexutre(scene->Get_SDLTexture("PlayerTexture"));
	titleTexture->SetFrameRate(0.5f);
	titleTexture->SetHorizonCount(3);
	titleTexture->SetVerticalCount(2);
	titleTexture->SetBlendMode(SDL_BLENDMODE_BLEND);
	titleTexture->SetAlpha(0xFF);
	titleTexture->SetAnimationActive(true);
	titleObject->transform->SetPosition(200, 200);
	titleObject->transform->SetWidth(100);
	titleObject->transform->SetHeight(100);
	titleObject->AddComponent<KeyboardTest>();
	scene->RegisterGameObject(titleObject);
}
