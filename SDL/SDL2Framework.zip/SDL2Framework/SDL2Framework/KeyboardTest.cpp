#include "KeyboardTest.h"
#include "Transform.h"
#include "Texture.h"
#include "GameManager.h"

KeyboardTest::KeyboardTest()
{
}


KeyboardTest::~KeyboardTest()
{
}

void KeyboardTest::Update(float deltaTime)
{
	// ��� Ű������ Ű ���¸� �������� �Լ�
	const Uint8* currentKeyStates = SDL_GetKeyboardState(NULL);
	
	if (currentKeyStates[SDL_SCANCODE_UP])
	{
		gameObject->transform->Move(0, -1);
	}
	if (currentKeyStates[SDL_SCANCODE_DOWN])
	{
		gameObject->transform->Move(0, 1);
	}
	if (currentKeyStates[SDL_SCANCODE_LEFT])
	{
		gameObject->transform->Move(-1, 0);
	}
	if (currentKeyStates[SDL_SCANCODE_RIGHT])
	{
		gameObject->transform->Move(1, 0);
	}
	if (currentKeyStates[SDL_SCANCODE_SPACE])
	{
		if(GameManager::Instance()->GetCurrentSceneName() == SceneName::MainMenu)
			GameManager::Instance()->ChangeScene(SceneName::Game);
		else
			GameManager::Instance()->ChangeScene(SceneName::MainMenu);
	}
}

void KeyboardTest::OnCollisionEnter(Collider * other)
{
	Texture* tex = gameObject->GetComponent<Texture>();
	if (tex != NULL)
	{
		tex->SetAlpha(0x20);
	}
}

void KeyboardTest::OnCollisionExit(Collider * other)
{
	Texture* tex = gameObject->GetComponent<Texture>();
	if (tex != NULL)
	{
		tex->SetAlpha(0xFF);
	}
}
