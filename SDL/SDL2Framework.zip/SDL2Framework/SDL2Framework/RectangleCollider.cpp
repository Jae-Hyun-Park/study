#include "RectangleCollider.h"
#include "CircleCollider.h"
#include "Transform.h"

RectangleCollider::RectangleCollider()
{
	type = Rectangle;
}

RectangleCollider::~RectangleCollider()
{
}

void RectangleCollider::Init()
{
	collisionRect = gameObject->transform->projRect;
}

void RectangleCollider::Update(float deltaTime)
{
	// transform�� ��ġ�� ���� collisionRect�� ���� ������ �ݴϴ�.
	collisionRect.x = gameObject->transform->projRect.x;
	collisionRect.y = gameObject->transform->projRect.y;
	collisionRect.w = gameObject->transform->projRect.w;
	collisionRect.h = gameObject->transform->projRect.h;
}