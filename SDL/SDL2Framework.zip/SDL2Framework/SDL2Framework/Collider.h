#pragma once
#include "Component.h"
#include <list>

using namespace std;

enum ColliderType
{
	Circle,
	Rectangle,
};

class Collider :
	public Component
{
public:
	ColliderType type;
	list<Collider*> enteredColliders;

	Collider* FindEnteredCollider(Collider* other);
	Collider();
	virtual ~Collider();
};

