#include "CircleCollider.h"
#include "RectangleCollider.h"
#include "Transform.h"
#include <cmath>

CircleCollider::CircleCollider()
{
	type = Circle;
}

CircleCollider::~CircleCollider()
{
}

void CircleCollider::Init()
{
	int x = gameObject->transform->projRect.x;
	int y = gameObject->transform->projRect.y;
	int w = gameObject->transform->projRect.w;
	int h = gameObject->transform->projRect.h;

	centerX = x + (w / 2);
	centerY = y + (h / 2);

	int xPow = (w / 2) * (w / 2);
	int yPow = (h / 2) * (h / 2);

	float distance =
		sqrtf((float)(xPow + yPow));

	radius = (int)distance;
}

void CircleCollider::Update(float deltaTime)
{
	UpdateCenter();
}

void CircleCollider::UpdateCenter()
{
	int x = gameObject->transform->projRect.x;
	int y = gameObject->transform->projRect.y;
	int w = gameObject->transform->projRect.w;
	int h = gameObject->transform->projRect.h;

	centerX = x + (w / 2);
	centerY = y + (h / 2);
}