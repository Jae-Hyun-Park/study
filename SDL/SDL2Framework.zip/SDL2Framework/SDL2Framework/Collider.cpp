#include "Collider.h"
#include "SDLFramework.h"
#include "Transform.h"

Collider * Collider::FindEnteredCollider(Collider* other)
{
	for (auto collider : enteredColliders)
	{
		if (collider == other)
			return collider;
	}

	return NULL;
}

Collider::Collider()
{
}

Collider::~Collider()
{
}