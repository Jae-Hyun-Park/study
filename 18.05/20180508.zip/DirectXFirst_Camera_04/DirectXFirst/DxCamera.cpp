#include "DxCamera.h"



DxCamera::DxCamera()
	:eyePosition(0,0,0)
	, lookAt(0.0f, 0.0f, 0.0f), upVector(0.0f, 1.0f, 0.0f),
	xAxis(1.0f, 0.0f, 0.0f), yAxis(0.0f, 1.0f, 0.0f), zAxis(0.0f, 0.0f, 1.0f),
	worldXAxis(1.0f, 0.0f, 0.0f), worldYAxis(0.0f, 1.0f, 0.0f), worldZAxis(0.0f, 0.0f, 1.0f)
{
	isFocused = true;
	accumYawDegrees = accumPitchDegrees = 0.0f;
}


DxCamera::~DxCamera()
{
}

void DxCamera::UpdateViewMatrix(LPDIRECT3DDEVICE9 g_pD3DDevice)
{
	D3DXQuaternionNormalize(&orientation, &orientation);
	D3DXMatrixRotationQuaternion(&viewMatrix, &orientation);

	xAxis = D3DXVECTOR3(viewMatrix(0, 0), viewMatrix(1, 0), viewMatrix(2, 0));
	yAxis = D3DXVECTOR3(viewMatrix(0, 1), viewMatrix(1, 1), viewMatrix(2, 1));
	zAxis = D3DXVECTOR3(viewMatrix(0, 2), viewMatrix(1, 2), viewMatrix(2, 2));
	viewDirection = zAxis;
	D3DXVec3Cross(&crossDirection, &yAxis, &viewDirection);

	viewMatrix(3, 0) = -D3DXVec3Dot(&xAxis, &eyePosition);
	viewMatrix(3, 1) = -D3DXVec3Dot(&yAxis, &eyePosition);
	viewMatrix(3, 2) = -D3DXVec3Dot(&zAxis, &eyePosition);

	g_pD3DDevice->SetTransform(D3DTS_VIEW, &viewMatrix);
}

void DxCamera::CameraRotate(float xDelta, float yDelta)
{
	accumPitchDegrees += yDelta;

	if (accumPitchDegrees > 60.0f)
	{
		yDelta = 0.0f;
		accumPitchDegrees = 60.0f;
	}

	if (accumPitchDegrees < -60.0f)
	{
		yDelta = 0.0f;
		accumPitchDegrees = -60.0f;
	}


	float yaw = -D3DXToRadian(xDelta);
	float pitch = -D3DXToRadian(yDelta);

	D3DXQUATERNION rotation;

	if (yaw != 0.0f)
	{
		D3DXQuaternionRotationAxis(&rotation, &worldYAxis, yaw);
		orientation = rotation * orientation;
		//D3DXQuaternionMultiply(&orientation, &rotation, &orientation);
	}

	if (pitch != 0.0f)
	{
		D3DXQuaternionRotationAxis(&rotation, &worldXAxis, pitch);
		orientation = orientation * rotation;
		//D3DXQuaternionMultiply(&orientation, &orientation, &rotation);
	}
}

void DxCamera::SetView(D3DXVECTOR3 * pvEye, D3DXVECTOR3 * pvLookAt, D3DXVECTOR3 * pvUp, LPDIRECT3DDEVICE9 g_pD3DDevice)
{
	eyePosition = *pvEye;
	lookAt = *pvLookAt;
	upVector = *pvUp;

	D3DXVec3Normalize(&viewDirection, &(lookAt - eyePosition));
	D3DXMatrixLookAtLH(&viewMatrix, &eyePosition, &lookAt, &upVector);
	D3DXVec3Cross(&crossDirection, &upVector, &viewDirection);

	// �������� �� ��ķ� ����� ����� viewMatrix��� �����մϴ�.
	g_pD3DDevice->SetTransform(D3DTS_VIEW, &viewMatrix);
}

void DxCamera::ProcessMouse()
{
	float mouseSpeed = 0.1f;	// ���콺 �ӵ�
	POINT pt;
	GetCursorPos(&pt);
	int dx = pt.x - currentMousePoint.x;		// ���콺�� X ��ȭ�� dx
	int dy = pt.y - currentMousePoint.y;		// ���콺�� X ��ȭ�� dy

	CameraRotate(dx * mouseSpeed, dy * mouseSpeed);

	RECT rt;
	GetClientRect(g_hWnd, &rt);

	pt.x = (rt.right - rt.left) / 2;
	pt.y = (rt.bottom - rt.top) / 2;
	ClientToScreen(g_hWnd, &pt);
	SetCursorPos(pt.x, pt.y);
	currentMousePoint = pt;
}
