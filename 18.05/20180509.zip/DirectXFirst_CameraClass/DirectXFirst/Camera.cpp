#include "Camera.h"

Camera::Camera(HWND hwnd, LPDIRECT3DDEVICE9 device, D3DXVECTOR3 pvEye, D3DXVECTOR3 pvLookAt, D3DXVECTOR3 pvUp) :
	_hWnd(hwnd), _pDevice(device), eyePosition(pvEye), lookAt(pvLookAt), upVector(pvUp),
	xAxis(1.0f, 0.0f, 0.0f), yAxis(0.0f, 1.0f, 0.0f), zAxis(0.0f, 0.0f, 1.0f),
	currentJumpVelocity(0.0f, 0.0f, 0.0f)
{
	D3DXMatrixIdentity(&viewMatrix);
	D3DXQuaternionIdentity(&orientation);

	D3DXVec3Normalize(&viewDirection, &(lookAt - eyePosition));
	D3DXMatrixLookAtLH(&viewMatrix, &eyePosition, &lookAt, &upVector);
	D3DXVec3Cross(&crossDirection, &upVector, &viewDirection);

	GetCursorPos(&currentMousePoint);
	// �������� �� ��ķ� ����� ����� viewMatrix��� �����մϴ�.
	_pDevice->SetTransform(D3DTS_VIEW, &viewMatrix);

	isFocused = true;
	State = NORMAL;
	accumYawDegrees = accumPitchDegrees = 0.0f;

	ShowCursor(FALSE);
}


Camera::~Camera()
{
}

void Camera::UpdateViewMatrix(float deltaTime)
{
	// --------- View ��� ����� ----------------------
	float deltaX = 0.f, deltaZ = 0.f;

	switch (State)
	{
	case NORMAL:
		break;
	case FORWARD:
		// W �������� // ����
		deltaZ += deltaTime * 20.0f;
		break;
	case BACK:
		// S �������� // ����
		deltaZ -= deltaTime * 20.0f;
		break;
	case LEFT:
		// A �������� // ���� �̵�
		deltaX -= deltaTime * 20.0f;
		break;
	case RIGHT:
		// D �������� // ������ �̵�
		deltaX += deltaTime * 20.0f;
		break;
	case LEFTFORWARD:
		// W, A �������� // ��������
		deltaZ += deltaTime * 20.0f;
		deltaX -= deltaTime * 20.0f;
		break;
	case RIGHTFORWARD:
		// W, D �������� // ����������
		deltaZ += deltaTime * 20.0f;
		deltaX += deltaTime * 20.0f;
		break;
	case LEFTBACK:
		// S, A �������� // ��������
		deltaZ -= deltaTime * 20.0f;
		deltaX -= deltaTime * 20.0f;
		break;
	case RIGHTBACK:
		// S, D �������� // ����������
		deltaZ -= deltaTime * 20.0f;
		deltaX += deltaTime * 20.0f;
		break;
	case JUMP:
		currentJumpVelocity.y -= deltaTime * gravity;

		eyePosition.y += currentJumpVelocity.y;
		if (eyePosition.y <= 0.0f)
		{
			eyePosition.y = 0.0f;
			State = NORMAL;
		}
		break;
	default:
		break;
	}

	D3DXVECTOR3 forwards;
	D3DXVec3Cross(&forwards, &crossDirection, &worldYAxis);
	D3DXVec3Normalize(&forwards, &forwards);

	eyePosition += forwards * deltaZ;
	eyePosition += crossDirection * deltaX;

	// ���콺�� ȸ�� ����� ���ϴ� �Լ� ȣ��
	if (isFocused)
		ProcessMouse();

	D3DXQuaternionNormalize(&orientation, &orientation);
	D3DXMatrixRotationQuaternion(&viewMatrix, &orientation);

	xAxis = D3DXVECTOR3(viewMatrix(0, 0), viewMatrix(1, 0), viewMatrix(2, 0));
	yAxis = D3DXVECTOR3(viewMatrix(0, 1), viewMatrix(1, 1), viewMatrix(2, 1));
	zAxis = D3DXVECTOR3(viewMatrix(0, 2), viewMatrix(1, 2), viewMatrix(2, 2));
	viewDirection = zAxis;
	D3DXVec3Cross(&crossDirection, &yAxis, &viewDirection);

	viewMatrix(3, 0) = -D3DXVec3Dot(&xAxis, &eyePosition);
	viewMatrix(3, 1) = -D3DXVec3Dot(&yAxis, &eyePosition);
	viewMatrix(3, 2) = -D3DXVec3Dot(&zAxis, &eyePosition);

	_pDevice->SetTransform(D3DTS_VIEW, &viewMatrix);
}

void Camera::ProcessMouse()
{
	float mouseSpeed = 0.1f;	// ���콺 �ӵ�
	POINT pt;
	GetCursorPos(&pt);
	int dx = pt.x - currentMousePoint.x;		// ���콺�� X ��ȭ�� dx
	int dy = pt.y - currentMousePoint.y;		// ���콺�� X ��ȭ�� dy

	CameraRotate(dx * mouseSpeed, dy * mouseSpeed);

	RECT rt;
	GetClientRect(_hWnd, &rt);

	pt.x = (rt.right - rt.left) / 2;
	pt.y = (rt.bottom - rt.top) / 2;
	ClientToScreen(_hWnd, &pt);
	SetCursorPos(pt.x, pt.y);
	currentMousePoint = pt;
}

void Camera::CameraRotate(float xDelta, float yDelta)
{
	accumPitchDegrees += yDelta;

	if (accumPitchDegrees > 60.0f)
	{
		yDelta = 0.0f;
		accumPitchDegrees = 60.0f;
	}

	if (accumPitchDegrees < -60.0f)
	{
		yDelta = 0.0f;
		accumPitchDegrees = -60.0f;
	}


	float yaw = -D3DXToRadian(xDelta);
	float pitch = -D3DXToRadian(yDelta);

	D3DXQUATERNION rotation;

	if (yaw != 0.0f)
	{
		D3DXQuaternionRotationAxis(&rotation, &worldYAxis, yaw);
		orientation = rotation * orientation;
	}

	if (pitch != 0.0f)
	{
		D3DXQuaternionRotationAxis(&rotation, &worldXAxis, pitch);
		orientation = orientation * rotation;
	}
}

void Camera::setWorldXYZAxis(D3DXVECTOR3 _x, D3DXVECTOR3 _y, D3DXVECTOR3 _z)
{
	worldXAxis.x = _x.x; worldXAxis.y = _x.y; worldXAxis.z = _x.z;
	worldYAxis.x = _y.x; worldYAxis.y = _y.y; worldYAxis.z = _y.z;
	worldZAxis.x = _z.x; worldZAxis.y = _z.y; worldZAxis.z = _z.z;

}
