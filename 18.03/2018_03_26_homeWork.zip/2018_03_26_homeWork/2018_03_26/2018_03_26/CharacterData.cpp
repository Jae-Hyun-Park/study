#include "CharacterData.h"



CharacterData::CharacterData()
{
}

CharacterData::CharacterData(FILE* _fp)  // ���Ͽ� �ִ� ĳ���� �����ͷ� �ʱ�ȭ
{
	name = new char[1];
	fscanf(_fp, "%s", name);
	fscanf(_fp, "%d", &job);
	fscanf(_fp, "%d", &strength);
	fscanf(_fp, "%d", &intelligence);
	fscanf(_fp, "%d", &agility);
}


CharacterData::~CharacterData()
{
	if (name != NULL) {
		delete[] name;
		name = NULL;
	}
}
