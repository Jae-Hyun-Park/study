#pragma once
#include <string>
#include <iostream>

using namespace std;
enum Job {
	Warrior,
	Wizard,
	Thief
};
class CharacterData
{
public:
	char* name;
	Job job;
	int strength;
	int intelligence;
	int agility;
	CharacterData();
	CharacterData(FILE* _fp);
	~CharacterData();
};

