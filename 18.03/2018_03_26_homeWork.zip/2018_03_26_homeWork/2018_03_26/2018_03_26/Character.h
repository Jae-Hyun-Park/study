#pragma once
#include "CharacterData.h"
#include <map>
enum turnType {
	attack,
	status
};
class Character
{
	int HpMax;
	int MpMax;
	int AtkBack;
	bool skillState = false;
public:
	CharacterData* data;
	int Hp;
	int Mp;
	int atkSpeed;
	int atk;
	int def;
	bool turnState = false;
	Character();
	Character(CharacterData* _data);
	~Character();

	void status();
	void rest();
	void atkBuffSkill();
	void atkBack();
	void playerAttack(map<string, Character*>::iterator& Enemy);
	void EnemyhpCheck(map<string, Character*>::iterator& Enemy, map<string, Character*>& Data);
};

