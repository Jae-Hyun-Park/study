#include <iostream>
#include <vector>
#include "item.h"
#include <map>

using namespace std;

void showitemVector(vector<item*>& v) {
	for (unsigned int i = 0; i < v.size(); ++i) {
		cout << i << "��° Item\nName = " << v[i]->name << "\nType = " << (int)v[i]->type << endl;
		if (i < v.size() - 1)
			cout << "==========================================================" << endl;
	}
}

int main(void) {
	vector<item*> ItemSet;

	ItemSet.reserve(6);
	ItemSet.push_back(new item("�ռҵ�", Sword, 10, 5, NULL, NULL));
	ItemSet.push_back(new item("���ҵ�", Sword, 5, 0, NULL, NULL));
	ItemSet.push_back(new item("�ٽ�Ÿ��ҵ�", Sword, 20, 3, NULL, NULL));
	ItemSet.push_back(new item("õ����", Armmor, 0, 5, NULL, NULL));
	ItemSet.push_back(new item("��ö����", Armmor, 5, 10, NULL, NULL));
	ItemSet.push_back(new item("�̽�������", Armmor, 10, 20, NULL, NULL));

	showitemVector(ItemSet);
	delete (*(ItemSet.end() - 1));
	ItemSet.pop_back();
	showitemVector(ItemSet);

}