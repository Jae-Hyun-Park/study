#include <iostream>
#include <map>

using namespace std;

int main() {
	int a = 11;
	int b = 8;
	map<int, int> maptest;
	maptest.insert(pair<int, int>(a, b));
	a = 3;
	b = 4;
	maptest.insert(pair<int, int>(a, b));
	a = 8;
	b = 9;
	maptest.insert(pair<int, int>(a, b));

	map<int, int>::iterator itor;
	for (itor = maptest.begin(); itor != maptest.end(); ++itor) {
		cout << itor->second << endl;
	}
	cout << endl;
	itor = maptest.find(3);
	cout << itor->second << endl;
	maptest.erase(itor);
	cout << endl;
	for (itor = maptest.begin(); itor != maptest.end(); ++itor) {
		cout << itor->second << endl;
	}
	return 0;
}