#include <iostream>
#include <list>
using namespace std;

void showIntList(list<int>& l) {
	list<int>::iterator iter = l.begin();
	int count = 1;
	for (; iter != l.end(); ++iter, ++count) {
		cout << "list " << count << " : " << *iter << endl;
	}
	cout << "==============================" << endl;
}
int main() {
	list<int> intlist;             // �⺻����
	list<int> intlist1(10);        // default�� 0���� 10�� ���� ����
	list<int> intlist2(2, 3);      // 3�ǰ��� ���� 2�� ���� ����
	list<int> intlist3(intlist2);  // list ����

	intlist.push_back(10);
	intlist.push_front(100);
	showIntList(intlist);
	list<int>::iterator iter = intlist.begin();

	int index = 1;
	for (int i = 0; i < index; ++i)
		iter++;
	intlist.insert(iter, 50);
	showIntList(intlist);
	iter = intlist.begin();

	index = 1;
	for (int i = 0; i < index; ++i)
		iter++;
	intlist.insert(iter, 40);
	showIntList(intlist);
	iter = intlist.begin();

	index = 3;
	for (int i = 0; i < index; ++i)
		iter++;
	intlist.erase(iter);
	showIntList(intlist);

	list<int>::reverse_iterator rIter = intlist.rbegin();
}