#include <iostream>
#include <list>

using namespace std;

void ShowIntList(list<int>& l)
{
	cout << endl;
	cout << " =========== ���� ����Ʈ ��� ============== " << endl;
	list<int>::iterator iter = l.begin();
	int count = 1;
	for (; iter != l.end(); ++iter, ++count)
	{
		cout << "list " << count << " : " << *iter << endl;
	}
}

int main()
{
	list<int> intList(3, 2);
	
	//list<int> intList2(intList);

	intList.push_back(10);
	intList.push_front(100);

	ShowIntList(intList);

	list<int>::iterator iter = intList.begin();
	int index = 3;
	for (int i = 0; i < index; ++i)
		iter++;
	intList.insert(iter, 50);
	ShowIntList(intList);

	index = 2;
	iter = intList.begin();
	for (int i = 0; i < index; ++i)
		iter++;
	intList.erase(iter);
	ShowIntList(intList);

	list<int>::reverse_iterator rIter = intList.rbegin();

	return 0;
}