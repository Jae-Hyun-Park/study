#pragma once
#include <iostream>

class Person {
protected :
	int age = 0;
	char* name = NULL;
public:
	Person();
	~Person();
	char* GetName() { return name; }
	Person(const char* _name, int _age);
	void Show();
};