#include "person.h"
#include <iostream>
using namespace std;


Person::Person()
{
}


Person::~Person()
{
	if (name != NULL && strlen(name) > 0)
		delete name;
}

Person::Person(const char* _name, int _age) {
	age = _age;
	name = new char[strlen(_name) + 1];
	strcpy(name, _name);
}

void Person::Show() {
	cout << "�̸� : " << name << '\t';
	cout << "���� : " << age << endl;
}