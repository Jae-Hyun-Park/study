#pragma once
#include "Behavior.h"
#include <random>

struct CharacterStatus {
	bool PlayerLife;
	int PlayerHp;
	int distanceToPlayer;
	int Sight;
	int Range;
};
class CheckInSight : public Node {
private:
	CharacterStatus * status;
public:
	CheckInSight(CharacterStatus* status) : status(status) {}
	virtual bool run() override {
		if (status->Sight > status->distanceToPlayer) {
			std::cout << "�÷��̾� �߰�!" << std::endl;
			return true;
		}
		else {
			std::cout << "������ �ʴ´�." << std::endl;
			std::cout << " �Ÿ� = " << status->distanceToPlayer << std::endl;
			return false;
		}
	}
};

class MoveRandom : public Node {
private:
	CharacterStatus * status;
	bool structed;
public:
	MoveRandom(CharacterStatus* status, bool structed) : status(status), structed(structed) {}

	int getRandomNumber(int min, int max)
	{
		//< 1�ܰ�. �õ� ����
		std::random_device rn;
		std::mt19937_64 rnd(rn());

		//< 2�ܰ�. ���� ���� ( ���� )
		std::uniform_int_distribution<int> range(min, max);

		//< 3�ܰ�. �� ����
		return range(rnd);
	}

	virtual bool run() override {
		if (structed) {
			std::cout << "��ֹ��� �ɷȴ�" << std::endl;
			return false;
		}
		else {
			std::cout << "���� �̵�" << std::endl;
			status->distanceToPlayer += getRandomNumber(-3, 1);
		}
		return false;
	}
};

class MoveToPlayer : public Node {
private:
	CharacterStatus * mstatus;
	bool structed;
public:
	MoveToPlayer(CharacterStatus* status, bool structed) : mstatus(status), structed(structed) {}
	virtual bool run() override {
		if (structed)
			return false;
		if (mstatus->distanceToPlayer > mstatus->Range) {
			std::cout << "�÷��̾�� �̵�" << std::endl;
			mstatus->distanceToPlayer--;
			if (mstatus->distanceToPlayer > mstatus->Range)
				std::cout << "�÷��̾� ������ �Ÿ� " << mstatus->distanceToPlayer << "���� �Ÿ�" << std::endl;
		}
		return true;
	}
};

class CheckAttackRange : public Node {
private:
	CharacterStatus * status;
public:
	CheckAttackRange(CharacterStatus* status) : status(status) {}
	virtual bool run() override {
		if (status->distanceToPlayer <= status->Range) {
			std::cout << "���ݰ���!" << std::endl;
			return true;
		}
		else {
			std::cout << "��Ÿ� �ۿ� �ִ�." << std::endl;
			return false;
		}
	}
};

class AttackToPlayer : public Node {
private:
	CharacterStatus * status;
public:
	AttackToPlayer(CharacterStatus* status) : status(status) {}
	virtual bool run() override {
		status->PlayerHp--;
		if (status->PlayerHp > 0) {
			std::cout << "Player Hp = " << status->PlayerHp << std::endl;
		}
		else {
			status->PlayerLife = true;
		}
		return status->PlayerLife;
	}
};

class IsPlayerDie : public Node {
private:
	CharacterStatus * status;
public:
	IsPlayerDie(CharacterStatus* status) : status(status) {}
	virtual bool run() override {
		if (status->PlayerLife == true)
			std::cout << "Player Die!" << std::endl;
		else
			std::cout << "Player Alive!" << std::endl;
		return status->PlayerLife;
	}
};

class Monster
{
private:
	CharacterStatus * MonStatus;

	Selector* selector1;
	CheckInSight* checkSight;
	MoveRandom* randMove;

	Sequence* sequence1;
	MoveToPlayer* move;
	CheckAttackRange* range;
	AttackToPlayer* attack;
	IsPlayerDie* Pd;

public:
	Sequence * PlayerKill;
	Monster();
	~Monster();
};

