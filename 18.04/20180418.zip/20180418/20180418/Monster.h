#pragma once
#include "Behavior.h"
#include "Map.h"
#include <random>

struct MonsterStatus {
	bool PlayerLife;
	int Hp;
	int distanceToPlayer;
	int Sight;
	int Range;
	int Locx;
	int Locy;
	int* PLocx;
	int* PLocy;
	int* PlayerHp;
};
class CheckInSight : public Node {
private:
	MonsterStatus * status;
public:
	CheckInSight(MonsterStatus* status) : status(status) {}
	virtual bool run() override {
		if (status->Sight >= status->distanceToPlayer) {
			std::cout << "�÷��̾� �߰�!" << std::endl;
			return true;
		}
		else {
			std::cout << "������ �ʴ´�." << std::endl;
			return false;
		}
	}
};

class MoveRandom : public Node {
private:
	MonsterStatus * status;
	Map* map;

public:
	MoveRandom(MonsterStatus* status, Map* map) : status(status), map(map) {}

	int getRandomNumber(int min, int max)
	{
		//< 1�ܰ�. �õ� ����
		std::random_device rn;
		std::mt19937_64 rnd(rn());

		//< 2�ܰ�. ���� ���� ( ���� )
		std::uniform_int_distribution<int> range(min, max);

		//< 3�ܰ�. �� ����
		return range(rnd);
	}

	virtual bool run() override {
		std::cout << "���� �̵�" << std::endl;
		int count = 0;
		bool direction = getRandomNumber(0, 1);
		int go = getRandomNumber(-1, 1);

		if (go == 0) {
			std::cout << "����" << std::endl;
			return false;
		}
		else if ((direction && (map->mapping[status->Locy][status->Locx + go] == WALL) ||
			(status->Locx + go > 9) || (status->Locx + go < 0)) ||
			((!direction) && (map->mapping[status->Locy + go][status->Locx] == WALL) ||
			(status->Locy + go > 9) || (status->Locy + go < 0))) {
			std::cout << "���̴� �̵��Ҽ� ����" << std::endl;
			return false;
		}
		else if ((direction && (map->mapping[status->Locy][status->Locx + go] == MONSTER) ||
			(status->Locx + go > 9) || (status->Locx + go < 0)) ||
			((!direction) && (map->mapping[status->Locy + go][status->Locx] == MONSTER) ||
			(status->Locy + go > 9) || (status->Locy + go < 0))) {
			std::cout << "�ٸ� ���Ͱ� �ִ� �̵��Ҽ� ����" << std::endl;
			return false;
		}
		else {
			if (direction) {
				status->Locx += go;
				status->distanceToPlayer = abs(status->Locx - *(status->PLocx)) + abs(status->Locy - *(status->PLocy));
			} else {
				status->Locy += go;
				status->distanceToPlayer = abs(status->Locx - *(status->PLocx)) + abs(status->Locy - *(status->PLocy));
			}
		}
		return false;
	}
};

class MoveToPlayer : public Node {
private:
	MonsterStatus * status;
	Map* map;
public:
	MoveToPlayer(MonsterStatus* status, Map* map) : status(status), map(map) {}

	int getRandomNumber(int min, int max)
	{
		//< 1�ܰ�. �õ� ����
		std::random_device rn;
		std::mt19937_64 rnd(rn());

		//< 2�ܰ�. ���� ���� ( ���� )
		std::uniform_int_distribution<int> range(min, max);

		//< 3�ܰ�. �� ����
		return range(rnd);
	}

	virtual bool run() override {
		if (status->distanceToPlayer > status->Range) {
			bool direction;
			direction = getRandomNumber(0, 1);
			int count = 0;
			std::cout << "�÷��̾�� �̵�" << std::endl;
			while (true)
			{
				if (direction) {
					if (status->Locx > *(status->PLocx) && (map->mapping[status->Locy][status->Locx - 1] == ROAD) &&
						(status->Locx - 1 < 9) && (status->Locx - 1 > 0)) {
						status->Locx--;
						break;
					}
					else if (status->Locx <= *(status->PLocx) && (map->mapping[status->Locy][status->Locx + 1] == ROAD) &&
						(status->Locx + 1 < 9) && (status->Locx + 1 > 0)) {
						status->Locx++;
						break;
					}
					else {
						direction = !direction;
						count++;
					}
				}

				if (!direction) {
					if (status->Locy > *(status->PLocy) && (map->mapping[status->Locy - 1][status->Locx] == ROAD) &&
						(status->Locy - 1 < 9) && (status->Locy - 1 > 0)) {
						status->Locy--;
						break;
					}
					else if (status->Locy <= *(status->PLocy) && (map->mapping[status->Locy + 1][status->Locx] == ROAD) &&
						(status->Locy + 1 < 9) && (status->Locy + 1 > 0)) {
						status->Locy++;
						break;
					}
					else {
						direction = !direction;
						count++;
					}
				}
				if (count > 1) {
					cout << "����" << endl;
					return false;
				}
			}
			status->distanceToPlayer = abs(status->Locx - *(status->PLocx)) + abs(status->Locy - *(status->PLocy));
			if (status->distanceToPlayer > status->Range)
				std::cout << "�÷��̾� ������ �Ÿ� = " << status->distanceToPlayer << std::endl;
		}
		return true;
	}
};

class CheckAttackRange : public Node {
private:
	MonsterStatus * status;
public:
	CheckAttackRange(MonsterStatus* status) : status(status) {}
	virtual bool run() override {
		if (status->distanceToPlayer <= status->Range) {
			std::cout << "���ݰ���!" << std::endl;
			return true;
		}
		else {
			std::cout << "��Ÿ� �ۿ� �ִ�." << std::endl;
			return false;
		}
	}
};

class AttackToPlayer : public Node {
private:
	MonsterStatus * status;
public:
	AttackToPlayer(MonsterStatus* status) : status(status) {}
	virtual bool run() override {
		if (--(*(status->PlayerHp)) > 0) {
			std::cout << "Player Hp = " << *(status->PlayerHp) << std::endl;
		}
		else {
			status->PlayerLife = true;
		}
		return status->PlayerLife;
	}
};

class IsPlayerDie : public Node {
private:
	MonsterStatus * status;
	Map* map;
public:
	IsPlayerDie(MonsterStatus* status, Map* map) : status(status), map(map) {}
	virtual bool run() override {
		if (status->PlayerLife == true) {
			std::cout << "Player Die!" << std::endl;
			map->mapping[*(status->PLocy)][*(status->PLocx)] = ROAD;
		}
		else
			std::cout << "Player Alive!" << std::endl;
		return status->PlayerLife;
	}
};

class Monster
{
private:
	Selector* selector1;
	CheckInSight* checkSight;
	MoveRandom* randMove;

	Sequence* sequence1;
	MoveToPlayer* move;
	CheckAttackRange* range;
	AttackToPlayer* attack;
	IsPlayerDie* Pd;

public:
	MonsterStatus * MonStatus;
	Map* map;
	Sequence * PlayerKill;
	void Init();
	Monster(bool PlayerLife, int PlayerHp, int distanceToPlayer, int Sight, int Range, int Locx, int Locy);
	~Monster();
};

