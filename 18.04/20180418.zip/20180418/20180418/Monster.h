#pragma once
#include "Behavior.h"
#include "Map.h"
#include <random>

struct CharacterStatus {
	bool PlayerLife;
	int PlayerHp;
	int distanceToPlayer;
	int Sight;
	int Range;
	int Locx;
	int Locy;
	int PLocx;
	int PLocy;
};
class CheckInSight : public Node {
private:
	CharacterStatus * status;
public:
	CheckInSight(CharacterStatus* status) : status(status) {}
	virtual bool run() override {
		if (status->Sight >= status->distanceToPlayer) {
			std::cout << "�÷��̾� �߰�!" << std::endl;
			return true;
		}
		else {
			std::cout << "������ �ʴ´�." << std::endl;
			std::cout << " �Ÿ� = " << status->distanceToPlayer << std::endl;
			return false;
		}
	}
};

class MoveRandom : public Node {
private:
	CharacterStatus * status;
	Map* map;

public:
	MoveRandom(CharacterStatus* status, Map* map) : status(status), map(map) {}

	int getRandomNumber(int min, int max)
	{
		//< 1�ܰ�. �õ� ����
		std::random_device rn;
		std::mt19937_64 rnd(rn());

		//< 2�ܰ�. ���� ���� ( ���� )
		std::uniform_int_distribution<int> range(min, max);

		//< 3�ܰ�. �� ����
		return range(rnd);
	}

	virtual bool run() override {
		std::cout << "���� �̵�" << std::endl;
		int count = 0;
		bool direction = getRandomNumber(0, 1);
		int go = getRandomNumber(-2, 2);

		if (go == 0) {
			std::cout << "����" << std::endl;
			return false;
		}
		else if ((direction && (map->mapping[status->Locy][status->Locx + go] == WALL)) ||
			((!direction) && (map->mapping[status->Locy + go][status->Locx] == WALL))) {
			std::cout << "���̴� �̵��Ҽ� ����" << std::endl;
			return false;
		}
		else {
			if (direction) {
				status->Locx += go;
				status->distanceToPlayer = abs(status->Locx - status->PLocx) + abs(status->Locy - status->PLocy);
				return false;
			} else {
				status->Locy += go;
				status->distanceToPlayer = abs(status->Locx - status->PLocx) + abs(status->Locy - status->PLocy);
				return false;
			}
		}
		return false;
	}
};

class MoveToPlayer : public Node {
private:
	CharacterStatus * mstatus;
	Map* map;
public:
	MoveToPlayer(CharacterStatus* status, Map* map) : mstatus(status), map(map) {}

	int getRandomNumber(int min, int max)
	{
		//< 1�ܰ�. �õ� ����
		std::random_device rn;
		std::mt19937_64 rnd(rn());

		//< 2�ܰ�. ���� ���� ( ���� )
		std::uniform_int_distribution<int> range(min, max);

		//< 3�ܰ�. �� ����
		return range(rnd);
	}

	virtual bool run() override {
		if (mstatus->distanceToPlayer > mstatus->Range) {
			bool direction;
			direction = getRandomNumber(0, 1);

			std::cout << "�÷��̾�� �̵�" << std::endl;
			while (true)
			{
				if (direction) {
					if (mstatus->Locx > mstatus->PLocx && (map->mapping[mstatus->Locy][mstatus->Locx - 1] != WALL)) {
						mstatus->Locx--;
						break;
					}
					else if (mstatus->Locx <= mstatus->PLocx && (map->mapping[mstatus->Locy][mstatus->Locx + 1] != WALL)) {
						mstatus->Locx++;
						break;
					}
					else
						direction = !direction;
				}

				if (!direction) {
					if (mstatus->Locy > mstatus->PLocy && (map->mapping[mstatus->Locy - 1][mstatus->Locx] != WALL)) {
						mstatus->Locy--;
						break;
					}
					else if (mstatus->Locy <= mstatus->PLocy && (map->mapping[mstatus->Locy + 1][mstatus->Locx] != WALL)) {
						mstatus->Locy++;
						break;
					}
					else
						direction = !direction;
				}
			}
			mstatus->distanceToPlayer = abs(mstatus->Locx - mstatus->PLocx) + abs(mstatus->Locy - mstatus->PLocy);
			if (mstatus->distanceToPlayer > mstatus->Range)
				std::cout << "�÷��̾� ������ �Ÿ� = " << mstatus->distanceToPlayer << std::endl;
		}
		return true;
	}
};

class CheckAttackRange : public Node {
private:
	CharacterStatus * status;
public:
	CheckAttackRange(CharacterStatus* status) : status(status) {}
	virtual bool run() override {
		if (status->distanceToPlayer <= status->Range) {
			std::cout << "���ݰ���!" << std::endl;
			return true;
		}
		else {
			std::cout << "��Ÿ� �ۿ� �ִ�." << std::endl;
			return false;
		}
	}
};

class AttackToPlayer : public Node {
private:
	CharacterStatus * status;
public:
	AttackToPlayer(CharacterStatus* status) : status(status) {}
	virtual bool run() override {
		status->PlayerHp--;
		if (status->PlayerHp > 0) {
			std::cout << "Player Hp = " << status->PlayerHp << std::endl;
		}
		else {
			status->PlayerLife = true;
		}
		return status->PlayerLife;
	}
};

class IsPlayerDie : public Node {
private:
	CharacterStatus * status;
	Map* map;
public:
	IsPlayerDie(CharacterStatus* status, Map* map) : status(status), map(map) {}
	virtual bool run() override {
		if (status->PlayerLife == true) {
			std::cout << "Player Die!" << std::endl;
			map->mapping[status->PLocy][status->PLocx] = ROAD;
		}
		else
			std::cout << "Player Alive!" << std::endl;
		return status->PlayerLife;
	}
};

class Monster
{
private:
	Selector* selector1;
	CheckInSight* checkSight;
	MoveRandom* randMove;

	Sequence* sequence1;
	MoveToPlayer* move;
	CheckAttackRange* range;
	AttackToPlayer* attack;
	IsPlayerDie* Pd;

public:
	CharacterStatus * MonStatus;
	Map* map;
	Sequence * PlayerKill;
	Monster();
	~Monster();
};

