#pragma once
#include "Behavior.h"
#include "Map.h"
#include <random>

struct PlayerStatus {
	bool MonsterLife;
	int Hp;
	int distanceToMonster;
	int Sight;
	int Range;
	int Locx;
	int Locy;
	int* MLocx;
	int* MLocy;
	int* MonsterHp;
};

class PCheckInSight : public Node {
private:
	PlayerStatus * status;
public:
	PCheckInSight(PlayerStatus* status) : status(status) {}
	virtual bool run() override {
		if (status->Sight >= status->distanceToMonster) {
			std::cout << "���� �߰�!" << std::endl;
			return true;
		}
		else {
			std::cout << "������ �ʴ´�." << std::endl;
			return false;
		}
	}
};
class PMoveRandom : public Node {
private:
	PlayerStatus * status;
	Map* map;

public:
	PMoveRandom(PlayerStatus* status, Map* map) : status(status), map(map) {}

	int getRandomNumber(int min, int max)
	{
		//< 1�ܰ�. �õ� ����
		std::random_device rn;
		std::mt19937_64 rnd(rn());

		//< 2�ܰ�. ���� ���� ( ���� )
		std::uniform_int_distribution<int> range(min, max);

		//< 3�ܰ�. �� ����
		return range(rnd);
	}

	virtual bool run() override {
		std::cout << "���� �̵�" << std::endl;
		int count = 0;
		bool direction = getRandomNumber(0, 1);
		int go = getRandomNumber(-1, 1);

		if (go == 0) {
			std::cout << "����" << std::endl;
			return false;
		}
		else if ((direction && (map->mapping[status->Locy][status->Locx + go] == WALL) ||
			(status->Locx + go > 9) || (status->Locx + go < 0)) ||
			((!direction) && (map->mapping[status->Locy + go][status->Locx] == WALL) ||
			(status->Locy + go > 9) || (status->Locy + go < 0))) {
			std::cout << "���̴� �̵��Ҽ� ����" << std::endl;
			return false;
		}
		else {
			if (direction) {
				status->Locx += go;
				status->distanceToMonster = abs(status->Locx - *(status->MLocx)) + abs(status->Locy - *(status->MLocy));
			}
			else {
				status->Locy += go;
				status->distanceToMonster = abs(status->Locx - *(status->MLocx)) + abs(status->Locy - *(status->MLocy));
			}
		}
		return false;
	}
};

class MoveToMonster : public Node {
private:
	PlayerStatus * status;
	Map* map;
public:
	MoveToMonster(PlayerStatus* status, Map* map) : status(status), map(map) {}

	int getRandomNumber(int min, int max)
	{
		//< 1�ܰ�. �õ� ����
		std::random_device rn;
		std::mt19937_64 rnd(rn());

		//< 2�ܰ�. ���� ���� ( ���� )
		std::uniform_int_distribution<int> range(min, max);

		//< 3�ܰ�. �� ����
		return range(rnd);
	}

	virtual bool run() override {
		if (status->distanceToMonster > status->Range) {
			bool direction;
			direction = getRandomNumber(0, 1);

			std::cout << "���ͷ� �̵�" << std::endl;
			while (true)
			{
				if (direction) {
					if (status->Locx > *(status->MLocx) && (map->mapping[status->Locy][status->Locx - 1] == ROAD) && 
						(status->Locx - 1 < 9) && (status->Locx - 1 > 0)) {
						status->Locx--;
						break;
					}
					else if (status->Locx <= *(status->MLocx) && (map->mapping[status->Locy][status->Locx + 1] == ROAD) &&
						(status->Locx + 1 < 9) && (status->Locx + 1 > 0)) {
						status->Locx++;
						break;
					}
					else
						direction = !direction;
				}

				if (!direction) {
					if (status->Locy > *(status->MLocy) && (map->mapping[status->Locy - 1][status->Locx] == ROAD) &&
						(status->Locy - 1 < 9) && (status->Locy - 1 > 0)) {
						status->Locy--;
						break;
					}
					else if (status->Locy <= *(status->MLocy) && (map->mapping[status->Locy + 1][status->Locx] == ROAD) &&
						(status->Locy + 1 < 9) && (status->Locy + 1 > 0)) {
						status->Locy++;
						break;
					}
					else
						direction = !direction;
				}
			}
			status->distanceToMonster = abs(status->Locx - *(status->MLocx)) + abs(status->Locy - *(status->MLocy));
			if (status->distanceToMonster > status->Range)
				std::cout << "���� ������ �Ÿ� = " << status->distanceToMonster << std::endl;
		}
		return false;
	}
};
class Player
{
private:
	Selector * selector1;
	PCheckInSight* checkSight;
	PMoveRandom* randMove;

	Sequence* sequence1;
	MoveToMonster* move;
public:
	PlayerStatus * playerStatus;
	Map* map;
	Sequence * MOVE;
	void Init();
	Player(bool MonsterLife, int MonsterHp, int distanceToMonster, int Sight, int Range, int Locx, int Locy);
	~Player();
};

