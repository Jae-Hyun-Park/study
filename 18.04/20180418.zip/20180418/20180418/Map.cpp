#include "Map.h"
#include "Monster.h"

Map::Map() {
}
void Map::buildMapping() {  // �� �ʱ�ȭ
	cout << "�� = Wall, �� = Player, �� = Goblin "<< endl;
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			switch (mapping[i][j]) {
			case ROAD:
				strcpy(pMap, road);
				pMap += 2;
				if (pMap == &maps[i][20])
					pMap++;
				break;

			case WALL:
				strcpy(pMap, wall);
				pMap += 2;
				if (pMap == &maps[i][20])
					pMap++;
				break;

			case PLAYER:
				strcpy(pMap, player);
				pMap += 2;
				if (pMap == &maps[i][20])
					pMap++;
				break;
			case MONSTER:
				strcpy(pMap, monster);
				pMap += 2;
				if (pMap == &maps[i][20])
					pMap++;
				break;
			default:
				break;
			}
		}
		cout << maps[i] << endl;
	}
	pMap = maps[0];
	return;
}

void Map::ViewMap() {   // �ʺ���
	buildMapping();
	return;
}

void Map::playerLocChecking(Monster* mon[], int size) {          // �÷��̾� ��ġüũ
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			if (mapping[i][j] == PLAYER || mapping[i][j] == MONSTER)
				mapping[i][j] = ROAD;
		}
	}
	mapping[*(mon[0]->MonStatus->PLocy)][*(mon[0]->MonStatus->PLocx)] = PLAYER;
	for (int i = 0; i < size; ++i)
		mapping[mon[i]->MonStatus->Locy][mon[i]->MonStatus->Locx] = MONSTER;
	//if (_mhp1 <= 0)
	//	mapping[_mlocy1][_mlocx1] = 0;
	//if (_mhp2 <= 0)
	//	mapping[_mlocy2][_mlocx2] = 0;
}

Map::~Map()
{
}
