#include "Map.h"

Map::Map() {
}
void Map::buildMapping() {  // �� �ʱ�ȭ
	cout << "�� = Wall, �� = Player, �� = Goblin "<< endl;
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			switch (mapping[i][j]) {
			case Road:
				strcpy(pMap, road);
				pMap += 2;
				if (pMap == &maps[i][20])
					pMap++;
				break;

			case Wall:
				strcpy(pMap, wall);
				pMap += 2;
				if (pMap == &maps[i][20])
					pMap++;
				break;

			case Player:
				strcpy(pMap, player);
				pMap += 2;
				if (pMap == &maps[i][20])
					pMap++;
				break;
			case Monster:
				strcpy(pMap, monster);
				pMap += 2;
				if (pMap == &maps[i][20])
					pMap++;
				break;
			default:
				break;
			}
		}
		cout << maps[i] << endl;
	}
	pMap = maps[0];
	return;
}

void Map::ViewMap() {   // �ʺ���
	buildMapping();
	return;
}

void Map::playerLocChecking(int _locx1, int _locy1, int _locx2, int _locy2) {          // �÷��̾� ��ġüũ
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			if (mapping[i][j] == 2 || mapping[i][j] == 3)
				mapping[i][j] = Road;
		}
	}
	mapping[_locy1][_locx1] = Player;
	mapping[_locy2][_locx2] = Monster;
	//if (_mhp1 <= 0)
	//	mapping[_mlocy1][_mlocx1] = 0;
	//if (_mhp2 <= 0)
	//	mapping[_mlocy2][_mlocx2] = 0;
}

Map::~Map()
{
}
