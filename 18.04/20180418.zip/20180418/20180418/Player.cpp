#include "Player.h"



void Player::Init()
{
	MOVE->addChild(selector1);

	selector1->addChild(checkSight);
	selector1->addChild(randMove);

	MOVE->addChild(sequence1);
	sequence1->addChild(move);
}

Player::Player (bool MonsterLife, int Hp, int distanceToMonster, int Sight, int Range, int Locx, int Locy)
{
	playerStatus = new PlayerStatus{ MonsterLife, Hp, distanceToMonster, Sight, Range, Locx, Locy, NULL, NULL, NULL};
	map = new Map();

	MOVE = new Sequence;

	selector1 = new Selector;
	checkSight = new PCheckInSight(playerStatus);
	randMove = new PMoveRandom(playerStatus, map);

	sequence1 = new Sequence;
	move = new MoveToMonster(playerStatus, map);
}


Player::~Player()
{
	delete move;
	delete randMove;
	delete checkSight;
	delete sequence1;
	delete selector1;
	delete MOVE;
	delete playerStatus;
	delete map;
}
