#include "Monster.h"

Monster::Monster()
{
	MonStatus = new CharacterStatus{ false, 10, 0, 5, 1, 1, 4, 8, 5};
	MonStatus->distanceToPlayer = abs(MonStatus->Locx - MonStatus->PLocx) + abs(MonStatus->Locy - MonStatus->PLocy);
	map = new Map();
	
	PlayerKill = new Sequence;

	selector1 = new Selector;
	checkSight = new CheckInSight(MonStatus);
	randMove = new MoveRandom(MonStatus, map);

	sequence1 = new Sequence;
	move = new MoveToPlayer(MonStatus, map);
	range = new CheckAttackRange(MonStatus);
	attack = new AttackToPlayer(MonStatus);
	Pd = new IsPlayerDie(MonStatus, map);

	PlayerKill->addChild(selector1);

	selector1->addChild(checkSight);
	selector1->addChild(randMove);

	PlayerKill->addChild(sequence1);
	sequence1->addChild(move);
	sequence1->addChild(range);
	sequence1->addChild(attack);
	sequence1->addChild(Pd);
}


Monster::~Monster()
{
	delete Pd;
	delete attack;
	delete range;
	delete move;
	delete randMove;
	delete checkSight;
	delete sequence1;
	delete selector1;
	delete PlayerKill;
	delete MonStatus;
	delete map;
}
