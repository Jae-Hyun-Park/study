#include "Monster.h"

void Monster::Init()
{
	PlayerKill->addChild(selector1);

	selector1->addChild(checkSight);
	selector1->addChild(randMove);

	PlayerKill->addChild(sequence1);
	sequence1->addChild(move);
	sequence1->addChild(range);
	sequence1->addChild(attack);
	sequence1->addChild(Pd);
}

Monster::Monster(bool PlayerLife, int Hp, int distanceToPlayer, int Sight, int Range, int Locx, int Locy)
{
	MonStatus = new MonsterStatus{ PlayerLife, Hp, distanceToPlayer, Sight, Range, Locx, Locy, NULL, NULL, NULL };
	map = new Map();
	
	PlayerKill = new Sequence;

	selector1 = new Selector;
	checkSight = new CheckInSight(MonStatus);
	randMove = new MoveRandom(MonStatus, map);

	sequence1 = new Sequence;
	move = new MoveToPlayer(MonStatus, map);
	range = new CheckAttackRange(MonStatus);
	attack = new AttackToPlayer(MonStatus);
	Pd = new IsPlayerDie(MonStatus, map);


}


Monster::~Monster()
{
	delete Pd;
	delete attack;
	delete range;
	delete move;
	delete randMove;
	delete checkSight;
	delete sequence1;
	delete selector1;
	delete PlayerKill;
	delete MonStatus;
	delete map;
}
