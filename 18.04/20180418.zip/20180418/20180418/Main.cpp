#include <Windows.h>
#include "Monster.h"
#include "Player.h"
int main() {
	Monster* orc[2];
	orc[0] = new Monster(false, 10, 0, 5, 1, 1, 4);
	orc[1] = new Monster(false, 10, 0, 4, 2, 1, 4);
	Player* player = new Player(false, 10, 0, 3, 2, 8, 5);
	//orc[0]->map->playerLocChecking(orc, 2);
	//orc[0]->map->ViewMap();

	Selector* root = new Selector;
	root->addChild(player->MOVE);
	player->playerStatus->MLocx = &(orc[0]->MonStatus->Locx);
	player->playerStatus->MLocy = &(orc[0]->MonStatus->Locy);
	player->playerStatus->MonsterHp = &(orc[0]->MonStatus->Hp);
	player->playerStatus->distanceToMonster = abs(player->playerStatus->Locx - *(player->playerStatus->MLocx)) + abs(player->playerStatus->Locy - *(player->playerStatus->MLocy));
	player->Init();
	for (int i = 0; i < 2; i++)
	{
		root->addChild(orc[i]->PlayerKill);
		orc[i]->MonStatus->PLocx = &(player->playerStatus->Locx);
		orc[i]->MonStatus->PLocy = &(player->playerStatus->Locy);
		orc[i]->MonStatus->PlayerHp = &(player->playerStatus->Hp);
		orc[i]->MonStatus->distanceToPlayer = abs(orc[i]->MonStatus->Locx - *(orc[i]->MonStatus->PLocx)) + abs(orc[i]->MonStatus->Locy - *(orc[i]->MonStatus->PLocy));
		orc[i]->Init();
	}
	while (!root->run())
	{
		orc[0]->map->playerLocChecking(orc, 2);
		orc[0]->map->ViewMap();
		std::cout << "----------------------" << std::endl;
		Sleep(500);
		system("cls");
	}
	std::cout << std::endl << "PlayerKill! close...." << std::endl;
	orc[0]->map->ViewMap();
	for (int i = 0; i < 2; ++i) {
		delete orc[i];
	}
}
