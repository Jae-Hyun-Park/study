#include "Monster.h"
#include <Windows.h>
int main() {
	Monster* orc = new Monster();

	while (!orc->PlayerKill->run())
	{
		std::cout << "----------------------" << std::endl;
		Sleep(1000);
	}

	std::cout << std::endl << "PlayerKill! close...." << std::endl;
	delete orc;
}
