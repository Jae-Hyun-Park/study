#include <Windows.h>
#include "Monster.h"
int main() {
	Monster* orc = new Monster();

	orc->map->playerLocChecking(orc->MonStatus->PLocx, orc->MonStatus->PLocy, orc->MonStatus->Locx, orc->MonStatus->Locy);
	orc->map->ViewMap();

	while (!orc->PlayerKill->run())
	{
		orc->map->playerLocChecking(orc->MonStatus->PLocx, orc->MonStatus->PLocy, orc->MonStatus->Locx, orc->MonStatus->Locy);
		orc->map->ViewMap();
		std::cout << "----------------------" << std::endl;
		Sleep(500);
	}
	std::cout << std::endl << "PlayerKill! close...." << std::endl;
	orc->map->ViewMap();
	delete orc;
}
