#pragma once
#include <iostream>
using namespace std;
const int mapSize = 10;

enum mapType {
	Road,
	Wall,
	Player,
	Monster,
};
class Map {
private:
	char maps[10][21];       // View�� �� �迭
	char* pMap = maps[0];
	const char* wall = "��";                 // �� ���ҽ� (��, ��, ���÷��̾�)
	const char* road = "��";
	const char* player = "��";
	const char* monster = "��";

public:
	mapType mapping[mapSize][mapSize] = {                    // ����
		{ Wall, Wall, Wall, Wall, Wall, Wall, Wall, Wall, Wall, Wall },
	{ Wall, Road, Wall, Road, Road, Road, Road, Wall, Road, Wall },
	{ Wall, Road, Wall, Road, Road, Wall, Road, Road, Road, Wall },
	{ Wall, Road, Road, Road, Road, Road, Road, Road, Wall, Wall },
	{ Wall, Road, Road, Road, Wall, Wall, Road, Road, Road, Wall },
	{ Wall, Road, Road, Road, Wall, Wall, Road, Road, Road, Wall },
	{ Wall, Wall, Road, Road, Road, Road, Road, Road, Road, Wall },
	{ Wall, Road, Road, Wall, Road, Road, Road, Wall, Road, Wall },
	{ Wall, Road, Road, Wall, Road, Wall, Wall, Road, Road, Wall },
	{ Wall, Wall, Wall, Wall, Wall, Wall, Wall, Wall, Wall, Wall } };

	void buildMapping();         // ���ʱ�ȭ�Լ�
	void ViewMap();              // �ʺ����Լ�
	void playerLocChecking(int _locx1, int _locy1, int _locx2, int _locy2);     // �÷��̾� ��ġ üũ

	Map();
	~Map();
};

