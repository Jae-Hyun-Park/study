#pragma once
#include <iostream>
using namespace std;
const int mapSize = 10;

enum mapType {
	ROAD,
	WALL,
	PLAYER,
	MONSTER,
};
class Map {
private:
	char maps[10][21];       // View�� �� �迭
	char* pMap = maps[0];
	const char* wall = "��";                 // �� ���ҽ� (��, ��, ���÷��̾�)
	const char* road = "��";
	const char* player = "��";
	const char* monster = "��";

public:
	mapType mapping[mapSize][mapSize] = {                    // ����
		{ WALL, WALL, WALL, WALL, WALL, WALL, WALL, WALL, WALL, WALL },
	{ WALL, ROAD, WALL, ROAD, ROAD, ROAD, ROAD, WALL, ROAD, WALL },
	{ WALL, ROAD, WALL, ROAD, ROAD, WALL, ROAD, ROAD, ROAD, WALL },
	{ WALL, ROAD, ROAD, ROAD, ROAD, ROAD, ROAD, ROAD, WALL, WALL },
	{ WALL, ROAD, ROAD, ROAD, WALL, WALL, ROAD, ROAD, ROAD, WALL },
	{ WALL, ROAD, ROAD, ROAD, WALL, WALL, ROAD, ROAD, ROAD, WALL },
	{ WALL, WALL, ROAD, ROAD, ROAD, ROAD, ROAD, ROAD, ROAD, WALL },
	{ WALL, ROAD, ROAD, WALL, ROAD, ROAD, ROAD, WALL, ROAD, WALL },
	{ WALL, ROAD, ROAD, WALL, ROAD, WALL, WALL, ROAD, ROAD, WALL },
	{ WALL, WALL, WALL, WALL, WALL, WALL, WALL, WALL, WALL, WALL } };

	void buildMapping();         // ���ʱ�ȭ�Լ�
	void ViewMap();              // �ʺ����Լ�
	void playerLocChecking(int _locx1, int _locy1, int _locx2, int _locy2);     // �÷��̾� ��ġ üũ

	Map();
	~Map();
};

