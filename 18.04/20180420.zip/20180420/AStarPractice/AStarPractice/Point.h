#pragma once
struct Point
{
	int x, y;
	bool operator == (const Point& coord)
	{
		return (x == coord.x && y == coord.y);
	}
};