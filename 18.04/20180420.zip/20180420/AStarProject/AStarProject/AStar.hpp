#include <vector>
#include <set>

struct Point
{
	int x, y;
	bool operator == (const Point& coordinates_);
	Point() { x = 0; y = 0;	}
	Point(int _x, int _y) { x = _x; y = _y; }
};

namespace AStar
{
    struct Node
    {
        unsigned int G, H;
        Point coordinates;
        Node *parent;

        Node(Point coord_, Node *parent_ = nullptr);
        unsigned int getScore();
    };

    using NodeSet = std::set<Node*>;

    class Generator
    {
        bool detectCollision(Point coordinates_);
        Node* findNodeOnList(NodeSet& nodes_, Point coordinates_);
        void releaseNodes(NodeSet& nodes_);

    public:
        Generator();
        void setWorldSize(Point worldSize_);
        void setDiagonalMovement(bool enable_);
        void setHeuristic(unsigned int(*heuristic_)(Point, Point));
		std::vector<Point> findPath(Point source_, Point target_);
        void addCollision(Point coordinates_);
        void removeCollision(Point coordinates_);
		bool checkCollision(Point coorinates_);
        void clearCollisions();
		Point getWorldSize() const { return worldSize; }
    private:
        unsigned int(*heuristic)(Point, Point);
		std::vector<Point> direction, walls;
        Point worldSize;
        unsigned int directions;
    };
}

class Heuristic
{
	static Point getDelta(Point source_, Point target_);

public:
	static unsigned int manhattan(Point source_, Point target_);
	static unsigned int euclidean(Point source_, Point target_);
	static unsigned int octagonal(Point source_, Point target_);
};