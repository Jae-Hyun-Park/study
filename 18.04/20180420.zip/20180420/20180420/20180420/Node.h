#pragma once
#include <list>
#include "Point.h"

using namespace std;

struct Node {

	Point coord;
	unsigned int G, H;
	Node* previousNode;

	Node(Point _coord, Node* _previous = nullptr) : coord(_coord), previousNode(_previous) {
		G = H = 0;
	}

	unsigned int GetCost() { return G + H; }
};

using NodeList = list<Node*>;

