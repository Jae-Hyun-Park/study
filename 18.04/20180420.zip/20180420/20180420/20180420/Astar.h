#pragma once
#include "Node.h"
#include "Map.h"

class Astar
{
	Map* map;
	vector<Point> direction;
	unsigned int directions;
	unsigned int(*heuristic)(Point, Point);

public:
	Astar(Map* _map, bool useDiagonal);
	~Astar();

	void SetUseDiagonalDirection(bool use) { directions = use ? 8 : 4; }
	vector<Point> FindPath(Point _start, Point _end);
	Node* FindNodeOnList(NodeList& nodeList, Point coord);
	void SetHeuristic(unsigned int(*_heuristic)(Point, Point));
};

class Heuristic
{
	static Point GetDelta(Point source, Point target);

public:
	static unsigned int Manhattan(Point source, Point target);
	static unsigned int Euclidean(Point source, Point target);
};