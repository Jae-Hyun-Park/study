#include <random>
#include <iostream>
#include "AStar.h"

int RandomGenerator(int min, int max)
{
	//< 1�ܰ�. �õ� ����
	random_device rn;
	mt19937_64 rnd(rn());

	//< 2�ܰ�. ���� ���� ( ���� )
	uniform_int_distribution<int> range(min, max);

	//< 3�ܰ�. �� ����
	return range(rnd);
}

Point objectPoint;

void Render(Map* map, Astar& astar, vector<Point> path, Point& start, Point& end)
{
	unsigned int pathIndex = path.size() - 1;
	while (pathIndex > 0)
	{
		system("pause");
		system("cls");

		for (int y = 0; y < map->GetSize().y; ++y)
		{
			for (int x = 0; x < map->GetSize().x; ++x)
			{
				if (map->CheckCollision({ x, y }))
				{
					cout << "��";
				}
				else if (start.x == x && start.y == y)
				{
					cout << "��";
				}
				else if (objectPoint.x == x && objectPoint.y == y)
				{
					cout << "��";
				}
				else if (end.x == x && end.y == y)
				{
					cout << "��";
				}
				else
				{
					cout << "  ";
				}
			}

			cout << endl;
		}

		pathIndex--;
		if (pathIndex >= 0)
			objectPoint = path[pathIndex];
	}
}

int main()
{
	Map* map = new Map();

	Astar astar(map, true);
	astar.SetHeuristic(Heuristic::Euclidean);

	Point startPoint;
	Point endPoint;

	startPoint.x = RandomGenerator(1, map->GetSize().x - 1);
	startPoint.y = RandomGenerator(1, map->GetSize().y - 1);

	endPoint.x = RandomGenerator(1, map->GetSize().x - 1);
	endPoint.y = RandomGenerator(1, map->GetSize().y - 1);

	map->RemoveCollision(startPoint);
	map->RemoveCollision(endPoint);

	objectPoint = startPoint;

	vector<Point> path = astar.FindPath(startPoint, endPoint);

	// Render
	Render(map, astar, path, startPoint, endPoint);

	return 0;
}