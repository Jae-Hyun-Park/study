#pragma once
struct Point
{
	int x, y;
	bool operator == (const Point& coord);
};

bool Point::operator == (const Point & coord)
{
	return (x == coord.x && y == coord.y);
}


Point operator + (const Point& left_, const Point& right_) {
	return { left_.x + right_.x, left_.y + right_.y };
}
