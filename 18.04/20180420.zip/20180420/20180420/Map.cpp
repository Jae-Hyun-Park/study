#include "Map.h"



Map::Map()
{
	FILE* fp = fopen("./map.txt", "rt");
	if (fp != NULL) {
		int mapWidth, mapHeight;
		fscanf(fp, "%d , %d", &mapWidth, &mapHeight);
		mapSize.x = mapWidth; mapSize.y = mapHeight;

		char buffer[256];
		fgets(buffer, mapWidth + 1, fp);

		for (int i = 0; i < mapHeight; ++i) {
			fgets(buffer, mapWidth + 1, fp);
			for (int j = 0; j < mapWidth; ++j) {
				// '|'�϶� collisions�� �߰�
				if (buffer[j] == '|')
					AddCollision({ j, i });
			}
		}
		fclose(fp);
	}
}


Map::~Map()
{
}

void Map::AddCollision(Point coord)
{
	collisions.push_back(coord);
}

bool Map::CheckCollision(Point coord)
{
	if (coord.x < 0 || coord.x > mapSize.x ||
		coord.y < 0 || coord.y > mapSize.y ||
		find(collisions.begin(), collisions.end(), coord) != collisions.end())
		return true;

	return false;
}
