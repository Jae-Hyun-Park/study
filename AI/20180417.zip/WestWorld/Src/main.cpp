#include "Locations.h"
#include "Miner.h"
#include "ConsoleUtils.h"
#include "EntityNames.h"

int main()
{
	//create a miner
	Miner miner(ent_Miner_Bob);

	//simply run the miner through a few Update calls
	//for (int i=0; i<20; ++i)
	while(true)
	{ 
		miner.Update();

		Sleep(1500);

		if (miner.Happiness() > 100)
		{
			std::cout << "�λ��� ��ǥ�� �޼��Ͽ���!!! : ���� �¸�!!!!" << std::endl;
			break;
		}
	}

	//wait for a keypress before exiting
	PressAnyKeyToContinue();

	return 0;
}