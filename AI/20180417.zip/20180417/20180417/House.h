#pragma once
#include "State.h"
#include "Bank.h"
class House :
	public State
{
private:
	Player * player;
	Bank * bank;
public:
	House(Bank* _bank);
	~House();
	void Enter(Player* _player);
	void Execution();
	void Exit();
};
