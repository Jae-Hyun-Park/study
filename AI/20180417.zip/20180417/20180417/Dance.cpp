#include "Dance.h"



Dance::Dance(Bar* _bar)
{
	bar = _bar;
}


Dance::~Dance()
{
}

void Dance::Enter(Player * _player)
{
	cout << "Ŭ������" << endl;
	player = _player;
	player->Current = DanCing;
}

void Dance::Execution()
{
	if (*(bar->bank->withdraw()) >= 4)
	{
		*(bar->bank->withdraw()) -= 3;
		player->Sp++;
		player->Mp++;
		player->Happy += 4;

		cout << "�����! Happy = " << player->Happy << " SP = " << player->Sp
			<< " MP = " << player->Mp << "������ = " << *(bar->bank->withdraw()) << endl;
	}
}

void Dance::Exit()
{
	if (player->Mp >= 10) {
		cout << "�񸶸��� ��������" << endl;
		cout << " ================================= " << endl;
		player->Go = Dringking;
		player = NULL;
	}
	else if (player->Sp >= 10 || *(bar->bank->withdraw()) < 4) {
		cout << "���� ����" << endl;
		cout << " ================================= " << endl;
		player->Go = Rest;
		player = NULL;
	}
}
