#include "Bar.h"



Bar::Bar(Bank* _bank)
{
	bank = _bank;
	player = NULL;
}


Bar::~Bar()
{
}

void Bar::Enter(Player * _player)
{
	cout << "��������" << endl;
	player = _player;
	player->Current = player->Go;
}

void Bar::Execution()
{
	if (*(bank->withdraw()) >= 1)
	{
		*(bank->withdraw()) -= 1;
		player->Mp -= 10;
		if (player->Mp <= 0)
			player->Mp = 0;
		cout << "�������� Mp = " << player->Mp <<
			"���� �� = " << *(bank->withdraw()) << endl;
	}
}

void Bar::Exit()
{
	if (player->Mp <= 10 && *(bank->withdraw()) <= player->GoalValue) {
		cout << "�ٽ� ��������" << endl;
		cout << " ================================= " << endl;
		player->Go = Mining;
		player = NULL;
	}
	else {
		cout << "���� ����" << endl;
		cout << " ================================= " << endl;
		player->Go = Rest;
		player = NULL;
	}
}
