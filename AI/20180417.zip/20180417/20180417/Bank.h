#pragma once
#include "State.h"

class Bank :
	public State
{
private:
	int Gold;
	int Goal;
	Player* player;

public:
	Bank();
	~Bank();
	void Enter(Player* _player);
	void Execution();
	void Exit();
	int* withdraw(){ return &Gold; }
};

