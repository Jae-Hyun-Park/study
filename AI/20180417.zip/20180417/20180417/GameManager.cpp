#include "GameManager.h"


GameManager::GameManager()
{
}


GameManager::~GameManager()
{
	delete bank;
	delete bar;
	delete house;
	delete mine;
	delete dance;
	delete player;
}

void GameManager::Init()
{
	bank = new Bank();
	bar = new Bar(bank);
	house = new House(bank);
	mine = new Mine();
	player = new Player();
	dance = new Dance(bar);
}

void GameManager::Update(float deltaTime)
{
	if (player->Go != player->Current)
	{
		switch (player->Go)
		{
		case Rest:
			house->Enter(player);
			break;
		case Mining:
			mine->Enter(player);
			break;
		case Dringking:
			bar->Enter(player);
			break;
		case Banking:
			bank->Enter(player);
			break;
		case DanCing:
			dance->Enter(player);
			break;
		default:
			cout << "error!" << endl;
			return;
		}
	}
	elapsedTime += deltaTime;
	if (elapsedTime > AIFrame)
	{
		switch (player->Current)
		{
		case Rest:
			house->Execution();
			house->Exit();
			break;
		case Mining:
			mine->Execution();
			mine->Exit();
			break;
		case Dringking:
			bar->Execution();
			bar->Exit();
			break;
		case Banking:
			bank->Execution();
			bank->Exit();
			break;
		case DanCing:
			dance->Execution();
			dance->Exit();
			break;
		default:
			cout << "error!" << endl;
			break;
		}
		elapsedTime = 0.0f;
	}
}
