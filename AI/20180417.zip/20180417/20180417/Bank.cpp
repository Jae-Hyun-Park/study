#include "Bank.h"


Bank::Bank()
{
	Gold = Goal = 0;
	player = NULL;
}

Bank::~Bank()
{
}

void Bank::Enter(Player * _player)
{
	cout << "���� ����" << endl;
	player = _player;
	player->Current = player->Go;
}

void Bank::Execution()
{
	Gold += player->Gold;
	Goal += Gold;
	cout << player->Gold << "�� ���� / ��ǥġ : " << Goal 
		<< "/" << player->GoalValue << endl;
	player->Gold = 0;
}

void Bank::Exit()
{
	if (player->GoalValue > Goal) {
		cout << "�ٽ� ��������" << endl;
		cout << " ================================= " << endl;
		player->Go = Mining;
		player = NULL;
	}
	else {
		cout << "���� ����" << endl;
		cout << " ================================= " << endl;
		player->Go = Rest;
		Goal = 0;
		player = NULL;
	}
}
