#pragma once
#include "Bar.h"
#include "House.h"
#include "Mine.h"
#include "Dance.h"

class GameManager
{
private:
	Bank * bank;
	Bar * bar;
	House* house;
	Mine* mine;
	Dance* dance;
	Player* player;

	float elapsedTime = 0.0f;
	float AIFrame = 192000000000.0f;
public:
	GameManager();
	~GameManager();
	
	void Init();
	void Update(float deltaTime);
	int playerHappy() { return player->Happy; }
};

