#pragma once

enum Going{
	Normal,
	Rest,
	Mining,
	Dringking,
	Banking,
	DanCing,
};

class Player
{
public:
	int Mp;
	int Sp;
	int Gold;
	int GoalValue;
	int Happy;
	Going Current;
	Going Go;
	Player();
	~Player();
};

