#include "House.h"



House::House(Bank* _bank)
{
	bank = _bank;
	player = NULL;
}

House::~House()
{
}

void House::Enter(Player * _player)
{
	cout << "�� ����" << endl;
	player = _player;
	player->Current = player->Go;
}

void House::Execution()
{
	player->Sp-= 3;
	player->Mp++;
	if (player->Sp <= 0)
		player->Sp = 0;
	cout << "ȸ�� �� ......" << endl;
	cout << "SP = " << player->Sp << " MP = " << player->Mp << endl;
}

void House::Exit()
{
	if (player->Sp == 0 && *(bank->withdraw()) < player->GoalValue)
	{
		cout << "�ٽ� ��������" << endl;
		cout << " ================================= " << endl;
		player->Go = Mining;
		player = NULL;
	}
	else if (player->Mp >= 10) {
		cout << "�񸶸��� ��������" << endl;
		cout << " ================================= " << endl;
		player->Go = Dringking;
		player = NULL;
	}
	else if (player->Sp == 0 && *(bank->withdraw()) >= player->GoalValue) {
		cout << "Ŭ������!" << endl;
		cout << " ================================= " << endl;
		player->Go = DanCing;
		player = NULL;
	}
}

