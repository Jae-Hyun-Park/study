#pragma once
#include "Player.h"
#include <iostream>

using namespace std;

class State
{
public:
	State() {}
	virtual ~State() {}

	virtual void Enter(Player* _player) = 0;
	virtual void Execution() = 0;
	virtual void Exit() = 0;
};