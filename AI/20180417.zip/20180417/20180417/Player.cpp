#include "Player.h"



Player::Player()
{
	Mp = 0;
	Sp = 0;
	Gold = 0;
	GoalValue = 10;
	Happy = 10;
	Go = Rest;
	Current = Normal;
}


Player::~Player()
{
}
