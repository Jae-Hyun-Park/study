#pragma once
#include "State.h"
class Mine :
	public State
{
	Player* player;
public:
	Mine();
	~Mine();
	void Enter(Player* _player);
	void Execution();
	void Exit();
};

