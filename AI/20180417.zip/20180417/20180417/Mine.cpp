#include "Mine.h"



Mine::Mine()
{
	player = NULL;
}


Mine::~Mine()
{
}

void Mine::Enter(Player * _player)
{
	cout << "���� ����" << endl;
	player = _player;
	player->Current = player->Go;
}

void Mine::Execution()
{
	player->Gold += 2;
	player->Sp++;
	player->Mp++;
	player->Happy--;
	cout << "���Ѵ� Gold = " << player->Gold << " SP = " << player->Sp
		<< " MP = " << player->Mp << "Happy = " << player->Happy << endl;
}

void Mine::Exit()
{
	if (player->Gold == player->GoalValue) {
		cout << "��ǥġ �޼� �����Ϸ� ����" << endl;
		cout << " ================================= " << endl;
		player->Go = Banking;
		player = NULL;
	}
	else if (player->Mp >= 10) {
		cout << "�񸶸��� ��������" << endl;
		cout << " ================================= " << endl;
		player->Go = Dringking;
		player = NULL;
	}
	else if (player->Sp >= 10) {
		cout << "����� ���� ����" << endl;
		cout << " ================================= " << endl;
		player->Go = Rest;
		player = NULL;
	}
}
