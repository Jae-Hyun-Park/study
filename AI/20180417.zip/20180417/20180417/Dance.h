#pragma once
#include "State.h"
#include "Bar.h"

class Dance :
	public State
{
private:
	Player * player;
	Bar* bar;
public:
	Dance(Bar* _bar);
	~Dance();
	void Enter(Player* _player);
	void Execution();
	void Exit();
};

