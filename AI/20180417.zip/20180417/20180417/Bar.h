#pragma once
#include "State.h"
#include "Bank.h"

class Bar :
	public State
{
private:
	Player* player;
public:
	Bank * bank;

	Bar(Bank* _bank);
	~Bar();
	void Enter(Player* _player);
	void Execution();
	void Exit();
};

